# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

import bpy
from bpy.props import (
        StringProperty
        )
    
class XarkinMessageDialog(bpy.types.Operator):
    bl_idname = "object.xarkin_message"
    bl_label = "Xarkin Message"
    bl_description = "General message dialog"

    msg: StringProperty()

    def execute(self, context):
        self.report({'INFO'}, self.msg)
        print(self.msg)
        return {'FINISHED'}

    def invoke(self, context, event):
        # return context.window_manager.invoke_popup(self)
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        lines = self.msg.split('\n')
        for line in lines:
            self.layout.label(text=line)

class XarkinNotImplementedDialog(bpy.types.Operator):
    bl_idname = "error.xarkin_not_implemented_message"
    bl_label = "Xarkin Not Implemented Message"
    bl_description = "Indicates possible future development"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self)

    def draw(self, context):
        self.layout.label(text='Operation not implemented.')


class XarkinOperationNotAvailableOperator(bpy.types.Operator):
    bl_idname = "object.xarkin_operation_not_available_operator"
    bl_label = "Not Available Notice"
    bl_description = "Indicates to the user that the selected feature is not available."

    def execute(self, context):
        bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='This feature is not available to your account.')
        return {'FINISHED'}
