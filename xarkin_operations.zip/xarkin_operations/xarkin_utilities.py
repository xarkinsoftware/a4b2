# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_SEGMENT_TAG = "segment"
XAR_NAME_ATTR = "name"
XAR_HEAD_ATTR = "head"
XAR_TAIL_ATTR = "tail"
XAR_NO_CYCLES_AVAILABLE = "No Cycles Available.  Try Refresh."
XAR_NONE = 'None'
XAR_STANDARD_NAME = 'Standard'
XAR_EARTH_GRAVITY_NAME = 'Earth Sea Level'
XAR_MOON_GRAVITY_NAME = 'Moon Surface'
XAR_MARS_GRAVITY_NAME = 'Mars Surface'
XAR_JUPITER_GRAVITY_NAME = 'Jupiter Virtual Surface'
XAR_CUSTOM_GRAVITY_NAME = 'Custom...'
XAR_EARTH_GRAVITY_VALUE = '-9.807'
XAR_MOON_GRAVITY_VALUE = '-1.625'
XAR_MARS_GRAVITY_VALUE = '-3.711'
XAR_JUPITER_GRAVITY_VALUE = '-25.9'
XAR_CUSTOM_GRAVITY_VALUE = '0'

import bpy
import math
import numpy
from mathutils import Vector, Matrix, Quaternion
import xml
import xml.dom
import xml.dom.minidom

format_str = "{:7.6f}"

def get_gravity_items(self, context):
    item_list = []
    earth_item = [XAR_EARTH_GRAVITY_VALUE, XAR_EARTH_GRAVITY_NAME, 'Earth gravity at sea level.']
    item_list.append(tuple(earth_item))

    moon_item = [XAR_MOON_GRAVITY_VALUE, XAR_MOON_GRAVITY_NAME, 'Gravity on the surface of the moon.']
    item_list.append(tuple(moon_item))

    mars_item = [XAR_MARS_GRAVITY_VALUE, XAR_MARS_GRAVITY_NAME, 'Gravity on the surface of mars.']
    item_list.append(tuple(mars_item))

    jupiter_item = [XAR_JUPITER_GRAVITY_VALUE, XAR_JUPITER_GRAVITY_NAME, 'Gravity on jupiter if it had a solid surface.']
    item_list.append(tuple(jupiter_item))

    jupiter_item = [XAR_CUSTOM_GRAVITY_VALUE, XAR_CUSTOM_GRAVITY_NAME, 'Custom gravity value.']
    item_list.append(tuple(jupiter_item))
    return item_list

def get_armature_items(self, context):
    item_list = []
    if hasattr(bpy.data, 'objects'):
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                next_item = [x.name, x.name, x.name]
                item_list.append(tuple(next_item))
    return item_list

def get_valid_mapping_items(armature_name, mappings_list):
    item_list = []
    if (mappings_list == None):
        item_list.append(tuple([XAR_NONE, XAR_NONE, XAR_NONE]))
    else:
        armature_bone_list = get_armature_bone_list(armature_name)
        for mapping_index in range(len(mappings_list)):
            if (same_string_array(mappings_list[mapping_index][2], armature_bone_list)):
                item_list.append(tuple([mappings_list[mapping_index][1], mappings_list[mapping_index][1], mappings_list[mapping_index][1]]))
        if (len(item_list) == 0):
            item_list.append(tuple([XAR_NONE, XAR_NONE, XAR_NONE]))
    return item_list

def get_valid_cycle_items(mapping_name, mappings_list, cycles_list):
    item_list = []
    topology = ''
    for mapping_index in range(len(mappings_list)):
        if (mappings_list[mapping_index][1] == mapping_name):
            topology = mappings_list[mapping_index][0]
    if (cycles_list == None) or (len(cycles_list) == 0):
        item_list.append(tuple([XAR_NONE, XAR_NONE, XAR_NONE]))
    else:
        for cycle_index in range(len(cycles_list)):
            if (cycles_list[cycle_index][0] == topology):
                item_list.append(tuple([cycles_list[cycle_index][1], cycles_list[cycle_index][1], cycles_list[cycle_index][1]]))
        if (len(item_list) == 0):
            item_list.append(tuple([XAR_NONE, XAR_NONE, XAR_NONE]))
    return item_list

def get_valid_source_items(armature_name, descriptor_list, user_name):
    item_list = []
    if (descriptor_list == None):
        item_list.append(tuple([XAR_NONE, XAR_NONE, XAR_NONE]))
    else:
        armature_bone_list = get_armature_bone_list(armature_name)
        additional_names = []
        standard_src_present = False
        for descriptor_index in range(len(descriptor_list)):
            if ((len(descriptor_list[descriptor_index]) < 3) or same_string_array(descriptor_list[descriptor_index][2], armature_bone_list)):
                if ((descriptor_list[descriptor_index][1].find(':') < 0) and (not standard_src_present)):
                    item_list.append(tuple([XAR_STANDARD_NAME, XAR_STANDARD_NAME, XAR_STANDARD_NAME]))
                    standard_src_present = True
        user_name_present = False
        for descriptor_index in range(len(descriptor_list)):
            if ((len(descriptor_list[descriptor_index]) < 3) or same_string_array(descriptor_list[descriptor_index][2], armature_bone_list)):
                colon_index = descriptor_list[descriptor_index][1].find(':')
                if (colon_index > 0):
                    map_source = descriptor_list[descriptor_index][1][0:colon_index]
                    user_name_present = user_name_present or (map_source == user_name)
                    if ((map_source != user_name) and (not (map_source in additional_names))):
                        additional_names.append(map_source)
        if (user_name_present):
            item_list.append(tuple([user_name, user_name, user_name]))
        additional_names.sort()
        for src_name in additional_names:
            item_list.append(tuple([src_name, src_name, src_name]))
        if (len(item_list) == 0):
            item_list.append(tuple([XAR_NONE, XAR_NONE, XAR_NONE]))
    return item_list

def get_valid_name_items(armature_name, descriptor_list, source_name, topology):
    item_list = []
    if (descriptor_list == None):
        item_list.append(tuple([XAR_NONE, XAR_NONE, XAR_NONE]))
    else:
        armature_bone_list = get_armature_bone_list(armature_name)
        name_list = []
        for descriptor_index in range(len(descriptor_list)):
            topology_match = (topology == None) or (descriptor_list[descriptor_index][0] == topology)
            bone_list_match = (len(descriptor_list[descriptor_index]) < 3) or same_string_array(descriptor_list[descriptor_index][2], armature_bone_list)
            if (topology_match and bone_list_match):
                colon_index = descriptor_list[descriptor_index][1].find(':')
                if (colon_index > 0):
                    map_source = descriptor_list[descriptor_index][1][0:colon_index]
                    map_name = descriptor_list[descriptor_index][1][colon_index + 1:]
                    if (map_source == source_name):
                        name_list.append(map_name)
                elif (source_name == XAR_STANDARD_NAME):
                    name_list.append(descriptor_list[descriptor_index][1])

        name_list.sort()
        for mp_name in name_list:
            item_list.append(tuple([mp_name, mp_name, mp_name]))
        if (len(item_list) == 0):
            item_list.append(tuple([XAR_NONE, XAR_NONE, XAR_NONE]))
    return item_list

def get_armature_bone_list(name):
    bone_list = []
    for x in bpy.data.objects:
        if ((str(x.type) == 'ARMATURE') and (x.name == name)):
            for bone in x.data.bones:
                bone_list.append(bone.name)
            bone_list.sort()
    return bone_list

def same_string_array(array1, array2):
    if (len(array1) != len(array2)):
        return False
    for i in range(len(array1)):
        if (array1[i] != array2[i]):
            return False
    return True

def extract_request_index(xmlStr):
    index = -1
    occurrence_index = xmlStr.find('request_index')
    if occurrence_index > 0:
        try:
            if len(xmlStr) > 200:
                substr = xmlStr[occurrence_index:190]
            else:
                substr = xmlStr[occurrence_index:]
            equals_parts = substr.split('=')
            quotes_parts = equals_parts[1].split('"')
            extracted_value = int(quotes_parts[1])
            index = extracted_value
        except Exception as exc:
            print("Failed to extract request index from\n" + substr + "\n" + str(exc))
    return index

def extract_response_note(xmlStr):
    note = ''
    occurrence_index = xmlStr.index('response_note')
    if occurrence_index > 0:
        try:
            if len(xmlStr) > 10000:
                substr = xmlStr[occurrence_index:9000]
            else:
                substr = xmlStr[occurrence_index:]
            equals_parts = substr.split('=')
            quotes_parts = equals_parts[1].split('"')
            note = quotes_parts[1]
        except Exception as exc:
            print("Failed to extract request index from\n" + substr + "\n" + str(exc))
    return note

def get_location_and_heading(arm):
    x_value = 0
    y_value = 0
    z_value = 0
    heading_value = 0
    for key in arm.data.bones.keys():
        if (not arm.pose.bones[key].parent):
            root_bone_length = (arm.pose.bones[key].tail - arm.pose.bones[key].head).length
            current_pose_matrix = arm.matrix_world.copy() @ (arm.data.bones[key].matrix_local.copy() @ arm.pose.bones[key].matrix_basis.copy())
            tail_location = current_pose_matrix @ Vector([0, root_bone_length, 0])
            x_value = tail_location.x
            y_value = tail_location.y
            z_value = tail_location.z

            heading_value = 0;
            down_ref = Vector([0, -1, 0])
            fwd_ref = Vector([0, 0, -1])
            basis_quat = arm.pose.bones[key].matrix_basis.to_quaternion()
            local_quat = arm.data.bones[key].matrix_local.to_quaternion()
            world_quat = arm.matrix_world.to_quaternion()
            fwd_root = (basis_quat @ (local_quat @ world_quat)) @ Vector([0, -1, 0])
            flat_fwd_root = fwd_root - down_ref * (down_ref.dot(fwd_root))
            if (flat_fwd_root.length > 0.000001):
                heading_value = math.acos(max(-1, min(1, flat_fwd_root.normalized().dot(fwd_ref))))
                if ((flat_fwd_root.cross(fwd_ref)).dot(down_ref) < 0):
                    heading_value *= -1
    return [x_value, y_value, z_value, heading_value]

def get_endpoint_location(arm, bone_name, head_or_tail):
    x_value = 0
    y_value = 0
    z_value = 0
    for key in arm.data.bones.keys():
        if (not arm.pose.bones[key].parent):
            root_data_bone = arm.data.bones[key]
    if (root_data_bone) and (bone_name in arm.pose.bones):
        pose_bone = arm.pose.bones[bone_name]
        data_bone = arm.data.bones[bone_name]
        if (head_or_tail):
            head_location = arm.matrix_world @ pose_bone.head
            x_value = head_location.x
            y_value = head_location.y
            z_value = head_location.z
        else:
            tail_location = arm.matrix_world @ pose_bone.tail
            x_value = tail_location.x
            y_value = tail_location.y
            z_value = tail_location.z

    return [x_value, y_value, z_value]

def vec_to_str(vector):
    return format_str.format(vector.x) + ',' + format_str.format(vector.y) + ',' + format_str.format(vector.z)

def str_to_vec(vector_str):
    parts = vector_str.split(',')
    x = float(parts[0])
    y = float(parts[1])
    z = float(parts[2])
    return Vector([x,y,z])
    
def get_segment_head(frame_node, seg_name):
    return get_segment_endpoint(frame_node, seg_name, XAR_HEAD_ATTR)

def get_segment_tail(frame_node, seg_name):
    return get_segment_endpoint(frame_node, seg_name, XAR_TAIL_ATTR)

def get_segment_endpoint(frame_node, seg_name, attr):
    for i in range(0, frame_node.childNodes.length):
        child_node = frame_node.childNodes[i]
        if (child_node.nodeName == XAR_SEGMENT_TAG):
            current_seg_name = child_node.attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
            if (current_seg_name == seg_name):
                return str_to_vec(child_node.attributes.getNamedItem(attr).nodeValue)
    return Vector([0, 0, 0])

def counter_rotate_frame(frame_xml, root_name, frame_heading):
    rotation_quat = Quaternion(Vector([0, 0, 1]), -frame_heading)
    frame_node = xml.dom.minidom.parseString(frame_xml)
    pivot_point = get_segment_tail(frame_node, root_name)
    attributes = [XAR_HEAD_ATTR, XAR_TAIL_ATTR]
    segment_nodes = frame_node.getElementsByTagName(XAR_SEGMENT_TAG)
    for seg_node in segment_nodes:
        if seg_node.attributes.getNamedItem(XAR_NAME_ATTR).nodeValue == root_name:
            continue
        for attr in attributes:
            seg_endpoint = str_to_vec(seg_node.attributes.getNamedItem(attr).nodeValue)
            endpoint_vec = seg_endpoint - pivot_point
            rotated_endpoint_vec = rotation_quat @ endpoint_vec
            new_endpoint = rotated_endpoint_vec + pivot_point
            new_endpoint_str = vec_to_str(new_endpoint)
            seg_node.setAttribute(attr, new_endpoint_str)
    counter_rotated_frame = frame_node.toxml()
    return counter_rotated_frame[counter_rotated_frame.find('<frame'):]
