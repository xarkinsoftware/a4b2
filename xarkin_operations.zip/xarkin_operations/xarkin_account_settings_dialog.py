# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_VALID_USERID_CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_'
XAR_VALID_PASSWORD_CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_!@#$%^*'

import bpy
import threading
import importlib
from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty
        )

from . import xarkin_session_data
from . import xarkin_message_dialog
from . import xarkin_utilities
from . import xarkin_network_service

global_dialog = None

def async_account_message(message):
    bpy.app.timers.register(lambda: show_account_response_message(None, message), first_interval=0)

def show_account_response_message(message_heading, message):
    if (message_heading == None) or (message_heading == ''):
        bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg=message)
    else:
        bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg=message_heading + ':\n' + message)

def valid_userid(self, context):
    userid = self.bootstrap_userid_prop
    corrected_userid = ''
    for char in userid:
        if char in XAR_VALID_USERID_CHARACTERS:
            corrected_userid = corrected_userid + char
    if not (self.bootstrap_userid_prop == corrected_userid):
        self.bootstrap_userid_prop = corrected_userid

    userid = self.new_userid_prop
    corrected_userid = ''
    for char in userid:
        if char in XAR_VALID_USERID_CHARACTERS:
            corrected_userid = corrected_userid + char
    if not (self.new_userid_prop == corrected_userid):
        self.new_userid_prop = corrected_userid

def valid_password(self, context):
    # Bootstrap password
    if (self.show_passwords_prop):
        password = self.bootstrap_password_prop_visible
    else:
        password = self.bootstrap_password_prop
    corrected_password = ''
    for char in password:
        if char in XAR_VALID_PASSWORD_CHARACTERS:
            corrected_password = corrected_password + char
    if not (self.bootstrap_password_prop == corrected_password):
        self.bootstrap_password_prop = corrected_password
    if not (self.bootstrap_password_prop_visible == corrected_password):
        self.bootstrap_password_prop_visible = corrected_password

    # Old password
    if (self.show_passwords_prop):
        password = self.old_password_prop_visible
    else:
        password = self.old_password_prop
    corrected_password = ''
    for char in password:
        if char in XAR_VALID_PASSWORD_CHARACTERS:
            corrected_password = corrected_password + char
    if not (self.old_password_prop == corrected_password):
        self.old_password_prop = corrected_password
    if not (self.old_password_prop_visible == corrected_password):
        self.old_password_prop_visible = corrected_password

    # New password
    if (self.show_passwords_prop):
        password = self.new_password_prop_visible
    else:
        password = self.new_password_prop
    corrected_password = ''
    for char in password:
        if char in XAR_VALID_PASSWORD_CHARACTERS:
            corrected_password = corrected_password + char
    if not (self.new_password_prop == corrected_password):
        self.new_password_prop = corrected_password
    if not (self.new_password_prop_visible == corrected_password):
        self.new_password_prop_visible = corrected_password

    # New password again
    if (self.show_passwords_prop):
        password = self.new_password_again_prop_visible
    else:
        password = self.new_password_again_prop
    corrected_password = ''
    for char in password:
        if char in XAR_VALID_PASSWORD_CHARACTERS:
            corrected_password = corrected_password + char
    if not (self.new_password_again_prop == corrected_password):
        self.new_password_again_prop = corrected_password
    if not (self.new_password_again_prop_visible == corrected_password):
        self.new_password_again_prop_visible = corrected_password

class XarkinAccountSettingsDialog(bpy.types.Operator):
    bl_idname = "object.xarkin_account_settings_dialog"
    bl_label = "Account Settings"
    bl_description = "Set or change userid and password for this session"

    current_userid = ''
    current_password = ''

    show_passwords_prop: BoolProperty(name="Show Passwords")

    bootstrap_userid_prop: StringProperty(name="Account Id", default="", update=valid_userid, description="Valid Characters are [a-z] [A-Z] [0-9] - _")
    bootstrap_password_prop: StringProperty(name="Password", subtype="PASSWORD", default="", update=valid_password, description="Valid Characters are [a-z] [A-Z] [0-9] - _ ! @ # $ % ^ & *\nMin Length: 8")
    bootstrap_password_prop_visible: StringProperty(name="Password", default="", update=valid_password, description="Valid Characters are [a-z] [A-Z] [0-9] - _ ! @ # $ % ^ & *\nMin Length: 8")

    new_userid_prop: StringProperty(name="New Account Id", default="", update=valid_userid, description="Valid Characters are [a-z] [A-Z] [0-9] - _")
    old_password_prop: StringProperty(name="Password", subtype="PASSWORD", default="", update=valid_password, description="Valid Characters are [a-z] [A-Z] [0-9] - _ ! @ # $ % ^ & *\nMin Length: 8")
    new_password_prop: StringProperty(name="New Password", subtype="PASSWORD", default="", update=valid_password, description="Valid Characters are [a-z] [A-Z] [0-9] - _ ! @ # $ % ^ & *\nMin Length: 8")
    new_password_again_prop: StringProperty(name="New Password Again", subtype="PASSWORD", default="", update=valid_password, description="Valid Characters are [a-z] [A-Z] [0-9] - _ ! @ # $ % ^ & *\nMin Length: 8")
    old_password_prop_visible: StringProperty(name="Password", default="", update=valid_password, description="Valid Characters are [a-z] [A-Z] [0-9] - _ ! @ # $ % ^ & *\nMin Length: 8")
    new_password_prop_visible: StringProperty(name="New Password", default="", update=valid_password, description="Valid Characters are [a-z] [A-Z] [0-9] - _ ! @ # $ % ^ & *\nMin Length: 8")
    new_password_again_prop_visible: StringProperty(name="New Password Again", default="", update=valid_password, description="Valid Characters are [a-z] [A-Z] [0-9] - _ ! @ # $ % ^ & *\nMin Length: 8")

    def draw(self, context):
        global global_dialog
        global_dialog = self
    
        layout = self.layout
        if (self.current_password == ''):
            layout.prop(self, 'bootstrap_userid_prop')
            layout.prop(self, 'show_passwords_prop')
            if (self.show_passwords_prop):
                layout.prop(self, 'bootstrap_password_prop_visible')
            else:
                layout.prop(self, 'bootstrap_password_prop')
        else:
            layout.label(text= 'Currently logged in as: ' + self.current_userid)
            layout.prop(self, 'new_userid_prop')
            layout.prop(self, 'show_passwords_prop')
            if (self.show_passwords_prop):
                layout.prop(self, 'old_password_prop_visible')
                if (self.new_userid_prop == self.current_userid):
                    layout.prop(self, 'new_password_prop_visible')
                    layout.prop(self, 'new_password_again_prop_visible')
            else:
                layout.prop(self, 'old_password_prop')
                if (self.new_userid_prop == self.current_userid):
                    layout.prop(self, 'new_password_prop')
                    layout.prop(self, 'new_password_again_prop')

    def invoke(self, context, event):
        self.show_passwords_prop = False
        [self.current_userid, self.current_password] = xarkin_session_data.fetch_userid_and_password()
        self.bootstrap_userid_prop = self.current_userid
        self.new_userid_prop = self.current_userid

        self.bootstrap_password_prop = ''
        self.bootstrap_password_prop_visible = ''

        self.old_password_prop = ''
        self.old_password_prop_visible = ''

        self.new_password_prop = ''
        self.new_password_prop_visible = ''

        self.new_password_again_prop = ''
        self.new_password_again_prop_visible = ''
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        if (self.current_password == ''):
            if (len(self.bootstrap_userid_prop) > 0) and (len(self.bootstrap_password_prop) > 0):
                xarkin_session_data.save_userid_and_password(self.bootstrap_userid_prop, self.bootstrap_password_prop)
        elif (self.new_userid_prop != self.current_userid):
            if (len(self.new_userid_prop) > 0) and (len(self.old_password_prop) > 0):
                xarkin_session_data.save_userid_and_password(self.new_userid_prop, self.old_password_prop)
        else:
            min_len = xarkin_network_service.XAR_MIN_PASSWORD_LENGTH
            if (self.old_password_prop_visible != self.current_password):
                async_account_message('Incorrect password for ' + self.current_userid)
            elif (self.new_password_prop != self.new_password_again_prop):
                async_account_message('Mismatched new password entries.')
            elif (len(self.new_password_prop) < min_len):
                async_account_message('New password too short.  Minimum length is ' + str(min_len) + '.')
            elif (self.new_password_prop != self.current_password):
                xarkin_network_service.set_user_id_and_password(self.new_userid_prop, self.new_password_prop)
        return {'FINISHED'}
