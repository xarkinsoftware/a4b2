# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

import datetime
import io
import os
import time
import math
import shutil
import bpy
import bmesh
import numpy
from mathutils import Vector, Matrix, Quaternion
import xml
import xml.dom
import xml.dom.minidom
import socket
import operator
import tempfile

from . import xarkin_utilities

XAR_ASSEMBLY_TAG = "assembly"
XAR_REST_TAG = "rest"
XAR_FRAME_TAG = "frame"
XAR_HEADING_ATTR = "heading"
XAR_SEQUENCE_TAG = "sequence"
XAR_FRAMERATE_ATTR = "frame_rate"

XAR_MOGEN_TAG = "mogen"

XAR_SEGMENT_TAG = "segment"
XAR_JOINT_TAG = "joint"
XAR_CONTACT_TAG = "contact"

XAR_INDEX_ATTR = "index"
XAR_NAME_ATTR = "name"
XAR_BONE_ROTATION = "rotation"
XAR_LENGTH_ATTR = "length"
XAR_BASE_ATTR = "base"
XAR_ADDED_ATTR = "added"
XAR_HEAD_ATTR = "head"
XAR_TAIL_ATTR = "tail"

XAR_USER_PARAMS_TAG = "user_params"
XAR_X_AXIS_ROTATION_TAG = "x_axis_rotation"
XAR_X_CROSS_REF_TAG = "x_cross_ref"
XAR_BONE_NAME_ATTR = "bone_name"
XAR_REF_NAME_ATTR = "ref_bone"
XAR_AXIS_ATTR = "axis"
XAR_JOINT_TYPE_ATTR = "type"
XAR_HINGE = "hinge"
XAR_INVISIBLE_MARKER = "fill_in_invisible"

XAR_MESH_SCALER = 1.25
XAR_MESH_RADIUS = 0.1

MIN_VECTOR_LENGTH = 0.00001

root_name = ""
x_axis_rotations = []
x_cross_ref = {}
root_fwd_ref = Vector([0,-1,0])
current_import_frame = -1
    
def set_select(object, isSelected):
    object.select_set(isSelected)
        
def set_active(object):
    bpy.context.view_layer.objects.active = object

def update_scene():
    bpy.context.view_layer.update()

def xarkin_editor_import_alert(message):
    bpy.ops.error.xeiep_message('INVOKE_DEFAULT', msg=message)
    
def get_vector_parameter(vector_str):
    parts = vector_str.split(',')
    x = float(parts[0])
    y = float(parts[1])
    z = float(parts[2])
    return Vector([x,y,z])
    
def get_segment_attribute(assembly_node, seg_name, attr):
    for i in range(0, assembly_node.childNodes.length):
        if (assembly_node.childNodes[i].nodeName == XAR_SEGMENT_TAG):
            current_seg_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
            if (current_seg_name == seg_name):
                return assembly_node.childNodes[i].attributes.getNamedItem(attr).nodeValue
    return ""
    
def get_segment_head_attribute(state_node, seg_name):
    for i in range(0, state_node.childNodes.length):
        if (state_node.childNodes[i].nodeName == XAR_SEGMENT_TAG):
            current_seg_name = state_node.childNodes[i].attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
            if (current_seg_name == seg_name):
                return state_node.childNodes[i].attributes.getNamedItem(XAR_HEAD_ATTR).nodeValue
    return ""
    
def get_segment_tail_attribute(state_node, seg_name):
    for i in range(0, state_node.childNodes.length):
        if (state_node.childNodes[i].nodeName == XAR_SEGMENT_TAG):
            current_seg_name = state_node.childNodes[i].attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
            if (current_seg_name == seg_name):
                return state_node.childNodes[i].attributes.getNamedItem(XAR_TAIL_ATTR).nodeValue
    return ""
    
def get_first_contact(state_node):
    for i in range(0, state_node.childNodes.length):
        if (state_node.childNodes[i].nodeName == XAR_CONTACT_TAG):
            contact_seg_name = state_node.childNodes[i].attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
            contact_index = state_node.childNodes[i].attributes.getNamedItem(XAR_INDEX_ATTR).nodeValue
            return [contact_seg_name, contact_index]
    return None
    
def get_joint_attribute(assembly_node, joint_name, attr):
    for i in range(0, assembly_node.childNodes.length):
        if (assembly_node.childNodes[i].nodeName == XAR_JOINT_TAG):
            current_joint_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
            if (current_joint_name == joint_name):
                if (assembly_node.childNodes[i].attributes.getNamedItem(attr) != None):
                    return assembly_node.childNodes[i].attributes.getNamedItem(attr).nodeValue
                else:
                    return ""
    return ""
    
def has_controlling_joint(assembly_node, seg_name):
    for i in range(0, assembly_node.childNodes.length):
        if (assembly_node.childNodes[i].nodeName == XAR_JOINT_TAG):
            joint_added_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_ADDED_ATTR).nodeValue
            if (seg_name == joint_added_name):
                return True
    return False
    
def get_controlling_joint_name(assembly_node, seg_name):
    for i in range(0, assembly_node.childNodes.length):
        if (assembly_node.childNodes[i].nodeName == XAR_JOINT_TAG):
            joint_added_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_ADDED_ATTR).nodeValue
            if (seg_name == joint_added_name):
                joint_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
                return joint_name
    return ""

def get_controlling_segment_name_allow_invisible(assembly_node, seg_name):
    for i in range(0, assembly_node.childNodes.length):
        if (assembly_node.childNodes[i].nodeName == XAR_JOINT_TAG):
            joint_added_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_ADDED_ATTR).nodeValue
            if (seg_name == joint_added_name):
                return assembly_node.childNodes[i].attributes.getNamedItem(XAR_BASE_ATTR).nodeValue
    return ""

def get_controlling_segment_name(assembly_node, seg_name):
    for i in range(0, assembly_node.childNodes.length):
        if (assembly_node.childNodes[i].nodeName == XAR_JOINT_TAG):
            joint_added_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_ADDED_ATTR).nodeValue
            if (seg_name == joint_added_name):
                base_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_BASE_ATTR).nodeValue
                if (base_name.endswith(XAR_INVISIBLE_MARKER)):
                    return get_controlling_segment_name(assembly_node, base_name)
                else:
                    return base_name
    return ""

def get_base_joint_names(assembly_node, seg_name):
    base_joint_names = []
    for i in range(0, assembly_node.childNodes.length):
        if (assembly_node.childNodes[i].nodeName == XAR_JOINT_TAG):
            joint_base_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_BASE_ATTR).nodeValue
            if (seg_name == joint_base_name):
                joint_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
                base_joint_names.append(joint_name)
    return base_joint_names
    
def get_added_segment_names(assembly_node, seg_name):
    added_segment_names = []
    for i in range(0, assembly_node.childNodes.length):
        if (assembly_node.childNodes[i].nodeName == XAR_JOINT_TAG):
            joint_base_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_BASE_ATTR).nodeValue
            if (seg_name == joint_base_name):
                added_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_ADDED_ATTR).nodeValue
                added_segment_names.append(added_name)
    return added_segment_names
    
def get_root_segment_name(assembly_node):
    for i in range(0, assembly_node.childNodes.length):
        if (assembly_node.childNodes[i].nodeName == XAR_SEGMENT_TAG):
            seg_name = assembly_node.childNodes[i].attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
            if (not has_controlling_joint(assembly_node, seg_name)):
                return seg_name
    return -1
    
def get_anchor_location(state_node):
    first_seg_node = state_node.getElementsByTagName(XAR_SEGMENT_TAG)[0]
    anchor_location = get_vector_parameter(first_seg_node.attributes.getNamedItem(XAR_TAIL_ATTR).nodeValue)
    return anchor_location

def get_anchor_head(state_node):
    first_seg_node = state_node.getElementsByTagName(XAR_SEGMENT_TAG)[0]
    anchor_location = get_vector_parameter(first_seg_node.attributes.getNamedItem(XAR_HEAD_ATTR).nodeValue)
    return anchor_location

def get_anchor_tail(state_node):
    first_seg_node = state_node.getElementsByTagName(XAR_SEGMENT_TAG)[0]
    anchor_tail = get_vector_parameter(first_seg_node.attributes.getNamedItem(XAR_TAIL_ATTR).nodeValue)
    return anchor_tail

def shift_state(state_node, shift_vector):
    format_str = "{:10.4f}"
    seg_nodes = state_node.getElementsByTagName(XAR_SEGMENT_TAG)
    for i in range(0, seg_nodes.length):
        seg_head_location = get_vector_parameter(seg_nodes[i].attributes.getNamedItem(XAR_HEAD_ATTR).nodeValue)
        new_head_location = seg_head_location + shift_vector
        new_head_str = format_str.format(new_head_location.x) + "," + format_str.format(new_head_location.y) + "," + format_str.format(new_head_location.z)
        seg_nodes[i].setAttribute(XAR_HEAD_ATTR, new_head_str)

        seg_tail_location = get_vector_parameter(seg_nodes[i].attributes.getNamedItem(XAR_TAIL_ATTR).nodeValue)
        new_tail_location = seg_tail_location + shift_vector
        new_tail_str = format_str.format(new_tail_location.x) + "," + format_str.format(new_tail_location.y) + "," + format_str.format(new_tail_location.z)
        seg_nodes[i].setAttribute(XAR_TAIL_ATTR, new_tail_str)

def rotate_segment(arm, seg_name, quat):
    pose_bone = arm.pose.bones[seg_name]
    arm_world_quat = arm.matrix_world.to_quaternion()
    current_world_quat = arm_world_quat @ get_relative_quat(arm, seg_name)

    basis_quat = pose_bone.matrix_basis.to_quaternion()
    basis_quat_inverted = basis_quat.copy().conjugated()

    new_basis = (current_world_quat @ basis_quat_inverted).conjugated() @ quat @ current_world_quat
    new_basis_as_4x4 = new_basis.to_matrix().to_4x4()

    pose_bone.matrix_basis = new_basis_as_4x4

def flatten_vector(ref_unit, subject_vector):
    return subject_vector - ref_unit * ref_unit.dot(subject_vector)

def get_current_segment_unit(arm, seg_name):
    current_matrix = arm.matrix_world @ get_relative_matrix(arm, seg_name)
    current_head = current_matrix @ Vector([0,0,0])
    current_tail = current_matrix @ Vector([0,1,0])
    current_vector = current_tail - current_head
    current_unit = current_vector.normalized()
    return current_unit
    
def get_current_segment_x_unit(arm, seg_name):
    current_matrix = arm.matrix_world @ get_relative_matrix(arm, seg_name)
    current_head = current_matrix @ Vector([0,0,0])
    current_tail = current_matrix @ Vector([1,0,0])
    current_vector = current_tail - current_head
    current_unit = current_vector.normalized()
    return current_unit
    
def get_current_segment_head(arm, seg_name):
    current_matrix = arm.matrix_world @ get_relative_matrix(arm, seg_name)
    current_head = current_matrix @ Vector([0,0,0])
    return current_head

def get_current_segment_perp(arm, seg_name):
    current_matrix = arm.matrix_world @ get_relative_matrix(arm, seg_name)
    current_head = current_matrix @ Vector([0,0,0])
    current_tail = current_matrix @ Vector([1,0,0])
    current_vector = current_tail - current_head
    current_unit = current_vector.normalized()
    return current_unit

def set_state_matrices(arm, assembly_node, state_node, frame_index, location_offset, heading_offset):
    global root_name
    global root_fwd_ref

    state_heading = 0
    if (state_node.hasAttribute(XAR_HEADING_ATTR)):
        state_heading = float(state_node.attributes.getNamedItem(XAR_HEADING_ATTR).nodeValue)

    seg_nodes = state_node.getElementsByTagName(XAR_SEGMENT_TAG)
    root_matrix = Quaternion([1.0,0.0,0.0,0.0]).to_matrix().to_4x4()

    root_x = 0
    root_y = 0
    root_z = 0

    for fIndex in range(len(arm.pose.bones.keys())):
        arm.pose.bones[arm.pose.bones.keys()[fIndex]].matrix_basis = Quaternion([1.0,0.0,0.0,0.0]).to_matrix().to_4x4()

    seg_name = None
    root_z_correction = 0
    for i in range(0, seg_nodes.length):
        include_location = False
        seg_name = seg_nodes[i].attributes.getNamedItem(XAR_NAME_ATTR).nodeValue
        if (arm.data.bones.keys().__contains__(seg_name)):
            if (root_name == ""):
                root_name = seg_name

            pose_bone = arm.pose.bones[seg_name]
            data_bone = arm.data.bones[seg_name]
            
            raw_given_head = get_vector_parameter(seg_nodes[i].attributes.getNamedItem(XAR_HEAD_ATTR).nodeValue)
            raw_given_tail = get_vector_parameter(seg_nodes[i].attributes.getNamedItem(XAR_TAIL_ATTR).nodeValue)

            if (seg_name == root_name):
                blender_root_head = arm.matrix_world @ arm.data.bones[root_name].head
                blender_root_tail = arm.matrix_world @ arm.data.bones[root_name].tail
                blender_root_vec = blender_root_tail - blender_root_head
                raw_given_head = raw_given_tail - blender_root_vec
            
            given_head = arm.matrix_world.copy().inverted() @ raw_given_head
            given_tail = arm.matrix_world.copy().inverted() @ raw_given_tail
            
            given_unit = (given_tail - given_head).normalized()
            
            current_unit = get_current_segment_unit(arm, seg_name)

            bone_rotation = 0
            if (seg_nodes[i].hasAttribute(XAR_BONE_ROTATION)):
                bone_rotation = float(seg_nodes[i].attributes.getNamedItem(XAR_BONE_ROTATION).nodeValue)
                
            rot_quat = Quaternion(current_unit, bone_rotation)

            if (seg_name == root_name):
                root_delta_y = data_bone.tail.y - data_bone.head.y
                root_delta_z = data_bone.tail.z - data_bone.head.z
                if (abs(root_delta_z) > abs(root_delta_y)):
                    if (root_delta_z > 0):
                        pose_bone.matrix = Quaternion(Vector([1,0,0]), math.pi / 2).to_matrix().to_4x4()
                        root_fwd_ref = Vector([0,0,1])
                    else:
                        pose_bone.matrix = Quaternion(Vector([1,0,0]), -math.pi / 2).to_matrix().to_4x4()
                        root_z_correction = 2 * root_length
                        root_fwd_ref = Vector([0,0,-1])
                else:
                    pose_bone.matrix = Quaternion(Vector([0,0,1]), 0).to_matrix().to_4x4()
                update_scene()

            if (seg_name != root_name):
                parent_name = pose_bone.parent.name
                current_parent_unit = get_current_segment_unit(arm, parent_name)
                major_axis_vector = current_parent_unit.cross(current_unit)
                joint_normal = major_axis_vector
                if (joint_normal.length > MIN_VECTOR_LENGTH):
                    joint_normal.normalize()
                    seg_x_unit = get_current_segment_x_unit(arm, seg_name)
                    seg_x_angle = math.acos(max(-1, min(1, seg_x_unit.dot(joint_normal))))
                    x_cross_normal = seg_x_unit.cross(joint_normal)
                    if (x_cross_normal.dot(current_unit) < 0):
                        seg_x_angle *= -1

            whole_axis = current_unit.cross(given_unit)
            if (whole_axis.length > MIN_VECTOR_LENGTH):
                if (seg_name != root_name):
                    if (major_axis_vector.length < MIN_VECTOR_LENGTH):
                        major_axis_vector = current_parent_unit.cross(given_unit)
                    if (major_axis_vector.length > MIN_VECTOR_LENGTH):
                        if (seg_name in x_cross_ref.keys()):
                            ref_bone_name = x_cross_ref[seg_name]
                            ref_bone_vector = get_current_segment_unit(arm, ref_bone_name)
                            major_axis_vector = current_unit.cross(ref_bone_vector)
                            if ((abs(major_axis_vector.x) < abs(major_axis_vector.y)) and (abs(major_axis_vector.x) < abs(major_axis_vector.z))):
                                major_axis_vector = flatten_vector(Vector([1,0,0]), major_axis_vector.copy())
                            elif ((abs(major_axis_vector.y) < abs(major_axis_vector.x)) and (abs(major_axis_vector.y) < abs(major_axis_vector.z))):
                                major_axis_vector = flatten_vector(Vector([0,1,0]), major_axis_vector.copy())
                            else:
                                major_axis_vector = flatten_vector(Vector([0,0,1]), major_axis_vector.copy())
                        elif (seg_name in x_axis_rotations):
                            major_axis_vector = Vector([1,0,0])

                        major_axis = major_axis_vector.normalized()
                        flattened_current = flatten_vector(major_axis, current_unit)
                        flattened_given = flatten_vector(major_axis, given_unit)
                        if ((flattened_current.length > MIN_VECTOR_LENGTH) and (flattened_given.length > MIN_VECTOR_LENGTH)):
                            major_axis_angle = math.acos(max(-1, min(1, flattened_current.normalized().dot(flattened_given.normalized()))))
                            if ((flattened_current.cross(flattened_given)).dot(major_axis) < 0):
                                major_axis_angle *= -1
                            major_quat = Quaternion(major_axis, major_axis_angle)
                            rotate_segment(arm, seg_name, major_quat)
                            current_unit = get_current_segment_unit(arm, seg_name)
                            rot_quat = Quaternion(current_unit, bone_rotation)

                minor_axis_vector = current_unit.cross(given_unit)
                if (minor_axis_vector.length > MIN_VECTOR_LENGTH):
                    minor_axis = minor_axis_vector.normalized()
                    minor_axis_angle = math.acos(max(-1, min(1, current_unit.dot(given_unit))))
                    minor_quat = Quaternion(minor_axis, minor_axis_angle) @ rot_quat
                    rotate_segment(arm, seg_name, minor_quat)
                else:
                    rotate_segment(arm, seg_name, rot_quat)
            elif ((seg_name != root_name) and (current_unit.dot(given_unit) < 0)):
                v_test_vec = current_unit.cross(Vector([0,1,0]))
                if (v_test_vec.length < MIN_VECTOR_LENGTH):
                    v_test_vec = current_unit.cross(Vector([1,0,0]))
                v_axis = v_test_vec.normalized()
                orientation_quat = Quaternion(v_axis, math.pi) @ rot_quat
                rotate_segment(arm, seg_name, orientation_quat)

            if (seg_name != root_name):
                controlling_joint_name = get_controlling_joint_name(assembly_node, seg_name)
                if (get_joint_attribute(assembly_node, controlling_joint_name, XAR_JOINT_TYPE_ATTR) == XAR_HINGE):
                    modified_seg_unit = get_current_segment_unit(arm, seg_name)
                    modified_joint_normal = current_parent_unit.cross(modified_seg_unit)
                    if ((joint_normal.length > MIN_VECTOR_LENGTH) and (modified_joint_normal.length > MIN_VECTOR_LENGTH)):
                        modified_joint_normal.normalize()
                        modified_seg_x_unit = get_current_segment_x_unit(arm, seg_name)
                        modified_seg_x_angle = math.acos(max(-1, min(1, modified_seg_x_unit.dot(modified_joint_normal))))
                        modified_x_cross_normal = modified_seg_x_unit.cross(modified_joint_normal)
                        if (modified_x_cross_normal.dot(modified_seg_unit) < 0):
                            modified_seg_x_angle *= -1
                        correction_rot_angle = seg_x_angle - modified_seg_x_angle
                        if (correction_rot_angle >= math.pi):
                            correction_rot_angle -= 2 * math.pi
                        if (correction_rot_angle <= -math.pi):
                            correction_rot_angle += 2 * math.pi
                        seg_hinge_rot_quat = Quaternion(modified_seg_unit, -correction_rot_angle)
                        rotate_segment(arm, seg_name, seg_hinge_rot_quat)

            if (seg_name == root_name):
                root_x = given_head.x
                root_y = given_head.y
                root_z = given_head.z
            else:
                controlling_seg = get_controlling_segment_name_allow_invisible(assembly_node, seg_name)
                if (controlling_seg.endswith(XAR_INVISIBLE_MARKER)):
                    fill_in_head_str = get_segment_head_attribute(state_node, controlling_seg)
                    fill_in_tail_str = get_segment_tail_attribute(state_node, controlling_seg)
                    fill_in_head = get_vector_parameter(fill_in_head_str)
                    fill_in_tail = get_vector_parameter(fill_in_tail_str)
                    if ((fill_in_tail - fill_in_head).length > 0.001):
                        mapped_seg_head = arm.matrix_world.copy().inverted() @ fill_in_tail
                        non_fill_in_seg = get_controlling_segment_name(assembly_node, controlling_seg)
                        non_fill_in_seg_tail_str = get_segment_tail_attribute(state_node, non_fill_in_seg)
                        non_fill_in_seg_tail = get_vector_parameter(non_fill_in_seg_tail_str)
                        mapped_non_fill_in_tail = arm.matrix_world.copy().inverted() @ non_fill_in_seg_tail
                        mapped_vec = mapped_seg_head - mapped_non_fill_in_tail
                        non_fill_in_tail = arm.pose.bones[non_fill_in_seg].tail.copy()
                        proposed_head = non_fill_in_tail + mapped_vec
                        seg_pose_head = pose_bone.head.copy()
                        pos_correction = proposed_head - seg_pose_head
                        rotated_pos_correction = arm.matrix_world.to_quaternion() @ pos_correction
                        rotated_pos_correction.x *= arm.scale.x
                        rotated_pos_correction.y *= arm.scale.y
                        rotated_pos_correction.z *= arm.scale.z
                        pose_bone.location = rotated_pos_correction
                        include_location = True

            if (frame_index >= 0):
                pose_bone.keyframe_insert(data_path='rotation_quaternion',frame=frame_index)
                if (include_location):
                    pose_bone.keyframe_insert(data_path='location',frame=frame_index)

            if (seg_name == root_name):
                root_matrix = pose_bone.matrix.copy()

    root_pose_bone = arm.pose.bones[root_name]

    heading = heading_offset + state_heading
    
    rot_axis = arm.matrix_world.to_quaternion().conjugated() @ Vector([0, 0, 1])
    rot_mat = Quaternion(rot_axis, heading).to_matrix().to_4x4()
    pos_rot_quat = Quaternion(rot_axis, heading_offset)

    local_location = Vector([root_x, root_y, root_z])
    whole_mat = rot_mat @ root_matrix
    
    rotated_location = pos_rot_quat @ local_location
    
    whole_mat.row[0].w += rotated_location.x + location_offset.x
    whole_mat.row[1].w += rotated_location.y + location_offset.y
    whole_mat.row[2].w += rotated_location.z + location_offset.z + root_z_correction
    
    root_pose_bone.matrix = whole_mat
    
    if (frame_index >= 0):
        root_pose_bone.keyframe_insert(data_path='rotation_quaternion',frame=frame_index)
        root_pose_bone.keyframe_insert(data_path='location',frame=frame_index)

    return rotated_location

def get_relative_matrix(arm, seg_name):
    mat_local = arm.data.bones[seg_name].matrix_local
    mat_basis = arm.pose.bones[seg_name].matrix_basis
    parent = arm.pose.bones[seg_name].parent
    if (parent == None):
        return mat_local @ mat_basis
    else:
        parent_mat_local = arm.data.bones[parent.name].matrix_local
        return get_relative_matrix(arm, parent.name) @ (parent_mat_local.inverted() @ mat_local) @ mat_basis

def get_relative_quat(arm, seg_name):
    quat_local = arm.data.bones[seg_name].matrix_local.to_quaternion()
    quat_basis = arm.pose.bones[seg_name].matrix_basis.to_quaternion()
    parent = arm.pose.bones[seg_name].parent
    if (parent == None):
        return quat_local @ quat_basis
    else:
        parent_quat_local = arm.data.bones[parent.name].matrix_local.to_quaternion()
        return get_relative_quat(arm, parent.name) @ (parent_quat_local.conjugated() @ quat_local) @ quat_basis

def add_segment(arm_obj, assembly_node, joint_name):
	base_seg_name = get_joint_attribute(assembly_node, joint_name, XAR_BASE_ATTR)
	added_seg_name = get_joint_attribute(assembly_node, joint_name, XAR_ADDED_ATTR)
	added_bone_length = float(get_segment_attribute(assembly_node, added_seg_name, XAR_LENGTH_ATTR))
	added_bone = arm_obj.data.edit_bones.new(added_seg_name)
	added_bone.head = arm_obj.data.edit_bones[base_seg_name].tail
		
	added_bone.tail = Vector([added_bone.head.x, added_bone.head.y, added_bone.head.z + added_bone_length])
	added_bone.roll = 0
	added_bone.parent = arm_obj.data.edit_bones[base_seg_name]
	added_bone.use_connect = True
	return added_seg_name
	
def instantiate_skeleton(name, assembly_node, rest_node):
    global root_name
    root_name = get_root_segment_name(assembly_node)

    root_z = 0
    if rest_node:
        root_tail_str = get_segment_attribute(rest_node, root_name, XAR_TAIL_ATTR)
        root_z = get_vector_parameter(root_tail_str).z

    arm_data = bpy.data.armatures.new(name + "_armature")
    arm_obj = bpy.data.objects.new(name, arm_data)
    arm_obj.matrix_world = Quaternion(Vector([1, 0, 0]), 0).to_matrix().to_4x4()
    bpy.context.scene.collection.objects.link(arm_obj)
    set_select(arm_obj, True)

    for i in bpy.context.scene.objects:
        set_select(i, False)
    set_select(arm_obj, True)
    set_active(arm_obj)
    bpy.ops.object.mode_set(mode='EDIT')

    root_bone = arm_obj.data.edit_bones.new(root_name)
    root_bone_length = float(get_segment_attribute(assembly_node, root_name, XAR_LENGTH_ATTR))
    root_bone.head = Vector([0.0, 0.0, root_z])
    root_bone.tail = Vector([0.0, 0.0, root_z + root_bone_length])
    
    current_segment_list = []
    next_segment_list = []
    
    current_segment_list.append(root_name)
    while (len(current_segment_list) > 0):
        for seg_name in current_segment_list:
            seg_joints = get_base_joint_names(assembly_node, seg_name)
            for joint_name in seg_joints:
                add_segment_name = add_segment(arm_obj, assembly_node, joint_name)
                next_segment_list.append(add_segment_name)
        current_segment_list.clear()
        for next_seg_name in next_segment_list:
            current_segment_list.append(next_seg_name)
        next_segment_list.clear()

    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.mode_set(mode='POSE')
    for bone in arm_obj.pose.bones:
        bone.bone.select = True
    bpy.ops.object.mode_set(mode='OBJECT')
    return arm_obj
    
def set_current_pose_to_rest(arm_obj):
    # select armature
    bpy.context.view_layer.objects.active = arm_obj
    arm_obj.select_set(True)
    # set armature to POSE mode
    bpy.ops.object.mode_set(mode='POSE')
    # Store the current pose bone locations
    pose_bones = {bone.name: bone.matrix.copy() for bone in arm_obj.pose.bones}
    # Switch to Edit Mode to make changes to the rest pose
    bpy.ops.object.mode_set(mode='EDIT')
    # Apply the stored pose matrices to the edit bones
    for bone_name, matrix in pose_bones.items():
        edit_bone = arm_obj.data.edit_bones[bone_name]
        edit_bone.matrix = matrix
    # Return to Object Mode to finalize changes
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.update()

    # Set rest pose onto surface
    bpy.ops.object.mode_set(mode='EDIT')
    min_z = min(bone.tail.z if bone.tail.z < bone.head.z else bone.head.z for bone in arm_obj.data.edit_bones)
    # Calculate how much to move the armature up to align the lowest point with z = 0
    translation_z = -min_z
    # Translate the armature to make the lowest point at z = 0
    for bone in arm_obj.data.edit_bones:
        bone.head.z += translation_z
        bone.tail.z += translation_z
    # Return to Object Mode
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.update()

    # Clear animation data
    if arm_obj.animation_data:
        arm_obj.animation_data_clear()
    # Clear pose transformations
    bpy.ops.object.mode_set(mode='POSE')
    for bone in arm_obj.pose.bones:
        bone.location = (0, 0, 0)
        bone.rotation_quaternion = (1, 0, 0, 0)
        bone.rotation_euler = (0, 0, 0)
        bone.scale = (1, 1, 1)
    bpy.context.view_layer.update()
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.update()

    # Set rest pose onto surface
    bpy.ops.object.mode_set(mode='EDIT')
    min_z = min(bone.tail.z if bone.tail.z < bone.head.z else bone.head.z for bone in arm_obj.data.edit_bones)
    # Calculate how much to move the armature up to align the lowest point with z = 0
    translation_z = -min_z
    # Translate the armature to make the lowest point at z = 0
    for bone in arm_obj.data.edit_bones:
        bone.head.z += translation_z
        bone.tail.z += translation_z
    # Return to Object Mode
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.update()

    # Clear pose transformations
    bpy.ops.object.mode_set(mode='POSE')
    for bone in arm_obj.pose.bones:
        bone.location = (0, 0, 0)
        bone.rotation_quaternion = (1, 0, 0, 0)
        bone.rotation_euler = (0, 0, 0)
        bone.scale = (1, 1, 1)
    bpy.context.view_layer.update()
    bpy.ops.object.mode_set(mode='OBJECT')

def initiate_frames_import(arm_name, sequence_xml, first_frame, remove_trailing_frames):
    global root_name
    global root_fwd_ref
    global x_axis_rotations
    global x_cross_ref
    global current_import_frame

    #root_name = ""
    x_axis_rotations = []
    x_cross_ref = {}
    root_fwd_ref = Vector([0,-1,0])

    print("Importing frames for " + str(arm_name) + " starting at " + str(first_frame))

    try:
        sequence_dom = xml.dom.minidom.parseString(sequence_xml)
    except:
        xarkin_editor_import_alert("Invalid sequence.")
        return False
        
    g_skeleton_node = sequence_dom.getElementsByTagName(XAR_ASSEMBLY_TAG)[0]
    root_name = get_root_segment_name(g_skeleton_node)
    rest_nodes = sequence_dom.getElementsByTagName(XAR_REST_TAG)
    if (rest_nodes.length > 0):
        rest_frame = rest_nodes[0]

    new_armature = False

    if (bpy.data.objects.find(arm_name) >= 0):
        armature = bpy.data.objects[arm_name]
        if (not armature.visible_get()):
            xarkin_editor_import_alert("Armature must be visible.")
            return False
        
        check_root_name = get_root_segment_name(g_skeleton_node)
        if (not armature.data.bones.keys().__contains__(check_root_name)):
            xarkin_editor_import_alert("Selected armature does not contain root node named '" + check_root_name + "'")
            return False
    else:
        armature = instantiate_skeleton(arm_name, g_skeleton_node, rest_frame)
        new_armature = True

    frames = {}
    frame_nodes = sequence_dom.getElementsByTagName(XAR_FRAME_TAG)
    current_frame = 0
    while (current_frame < frame_nodes.length):
        frame_node = frame_nodes[current_frame]
        frame_index = int(frame_node.attributes.getNamedItem(XAR_INDEX_ATTR).nodeValue)
        if (frame_index >= 0):
            frames[frame_index] = frame_node
        else:
            rest_frame = frame_node
        current_frame += 1
    sorted_frame_keys = sorted(frames.keys())

    initial_x = 0
    initial_y = 0
    initial_z = 0
    initial_heading = 0

    first_incoming_frame = frames[sorted_frame_keys[0]]
    contact_spec = get_first_contact(first_incoming_frame)
    if (contact_spec == None):
        use_contact_alignment = False
    else:
        use_contact_alignment = True
        contact_bone_name = contact_spec[0]
        contact_bone_head_or_tail = (contact_spec[1] == '0')

    if (first_frame == 0) or ((first_frame <= 2) and not use_contact_alignment):
        bpy.context.scene.frame_current = first_frame
        update_scene()
        [initial_x, initial_y, initial_z, initial_heading] = xarkin_utilities.get_location_and_heading(armature)
    elif use_contact_alignment:
        if (first_frame > 1):
            bpy.context.scene.frame_current = first_frame - 1
        else:
            bpy.context.scene.frame_current = first_frame
        update_scene()
        if contact_bone_head_or_tail:
            bone_head_str = get_segment_head_attribute(first_incoming_frame, contact_bone_name)
            sequence_contact_location = get_vector_parameter(bone_head_str)
        else:
            bone_tail_str = get_segment_tail_attribute(first_incoming_frame, contact_bone_name)
            sequence_contact_location = get_vector_parameter(bone_tail_str)

        e_x_minus_1 = 0
        e_y_minus_1 = 0
        e_z_minus_1 = 0
        [e_x_minus_1, e_y_minus_1, e_z_minus_1] = xarkin_utilities.get_endpoint_location(armature, contact_bone_name, contact_bone_head_or_tail)

        root_tail_str = get_segment_tail_attribute(first_incoming_frame, root_name)
        sequence_root_location = get_vector_parameter(root_tail_str)
        sequence_root_to_contact_vector = sequence_contact_location - sequence_root_location
        initial_x = e_x_minus_1 - sequence_root_to_contact_vector.x
        initial_y = e_y_minus_1 - sequence_root_to_contact_vector.y
        initial_z = e_z_minus_1 - sequence_root_to_contact_vector.z
    else:
        bpy.context.scene.frame_current = first_frame - 2
        update_scene()
        root_x_minus_2 = 0
        root_y_minus_2 = 0
        root_z_minus_2 = 0
        [root_x_minus_2, root_y_minus_2, root_z_minus_2, init_heading] = xarkin_utilities.get_location_and_heading(armature)
        bpy.context.scene.frame_current = first_frame - 1
        update_scene()
        root_x_minus_1 = 0
        root_y_minus_1 = 0
        root_z_minus_1 = 0
        [root_x_minus_1, root_y_minus_1, root_z_minus_1, initial_heading] = xarkin_utilities.get_location_and_heading(armature)
        first_frame_heading = 0
        if (first_incoming_frame.hasAttribute(XAR_HEADING_ATTR)):
            first_frame_heading = float(first_incoming_frame.attributes.getNamedItem(XAR_HEADING_ATTR).nodeValue)
        initial_heading = first_frame_heading - initial_heading
        initial_x = 2 * root_x_minus_1 - root_x_minus_2
        initial_y = 2 * root_y_minus_1 - root_y_minus_2
        initial_z = 2 * root_z_minus_1 - root_z_minus_2

    initial_location_offset = armature.matrix_world.copy().inverted() @ Vector([initial_x, initial_y, initial_z])
    origin_point = armature.matrix_world.copy().inverted() @ Vector([0, 0, 0])
    location_offset = initial_location_offset - origin_point
    
    sequence_node = sequence_dom.getElementsByTagName(XAR_SEQUENCE_TAG)[0]
    frame_rate = float(sequence_node.attributes.getNamedItem(XAR_FRAMERATE_ATTR).nodeValue)
    
    for fIndex in range(len(sorted_frame_keys)):
        frame_index = sorted_frame_keys[fIndex]
        if (fIndex == 0):
            correction = get_anchor_location(frames[frame_index])
            correction *= -1
        shift_state(frames[frame_index], correction)

    bpy.context.scene.render.fps = int(frame_rate)

    try:
        bpy.ops.object.select_all(action='DESELECT')
        set_active(bpy.context.scene.objects[arm_name])
        bpy.ops.object.mode_set(mode='POSE')
    except:
        print("Failed to enter POSE mode")
        return False

    heading_offset = initial_heading

    entire_frame_index = 1
    current_import_frame = -1
    for fIndex in range(len(sorted_frame_keys)):
        frame_index = sorted_frame_keys[fIndex]
        entire_frame_index = frame_index + first_frame
        current_import_frame = entire_frame_index
        print("Importing frame " + str(current_import_frame))
        location_vector = set_state_matrices(armature, g_skeleton_node, frames[frame_index], entire_frame_index, location_offset, heading_offset)
        if (fIndex == 0) and new_armature:
            set_current_pose_to_rest(armature)

    if (remove_trailing_frames and (current_import_frame > -1)):
        print("Removing keyframes for " + arm_name + " after " + str(current_import_frame))
        if armature.animation_data:
            for fcurve in armature.animation_data.action.fcurves:
                keyframe_points = fcurve.keyframe_points
                for i in range(len(keyframe_points) -1, -1, -1):
                    if keyframe_points[i].co.x > current_import_frame:
                        keyframe_points.remove(keyframe_points[i])

    bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Import complete.')

    bpy.context.scene.frame_current = first_frame
    if (bpy.context.scene.frame_end < entire_frame_index):
        bpy.context.scene.frame_end = entire_frame_index

    try:
        set_active(armature)
        bpy.ops.object.mode_set(mode='OBJECT')
    except:
        return False

    bpy.ops.object.select_all(action='DESELECT')
    set_select(armature, True)
    return {'FINISHED'}
    