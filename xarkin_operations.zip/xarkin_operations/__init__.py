# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

bl_info = {
    "name": "Xarkin Animation",
    "author": "Mike Kelly",
    "version": (0, 3, 7),
    "blender": (3, 1, 0),
    "location": "View3D",
    "description": "Access Xarkin Animation Services",
    "warning": "",
    "doc_url": "www.xarkinsoftware.com",
    "category": "Simulation",
}

import bpy
import atexit
import time
import threading
from bpy.utils import previews
from bpy.types import Menu

from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty,
        CollectionProperty
        )

from . import xarkin_account_settings_dialog
from . import xarkin_walk_step_dialog
from . import xarkin_run_step_dialog
from . import xarkin_turn_dialog
from . import xarkin_session_data
from . import xarkin_network_service
from . import xarkin_null_abort_operator
from . import xarkin_import_frames_operator
from . import xarkin_single_capture_dialog
from . import xarkin_gesture_capture_dialog
from . import xarkin_append_cycle_dialog
from . import xarkin_append_elements_dialog
from . import xarkin_append_transition_dialog
from . import xarkin_refresh_operator
from . import xarkin_create_mapping_operator
from . import xarkin_cycle_editor_dialog
from . import xarkin_single_editor_dialog
from . import xarkin_gesture_editor_dialog
from . import xarkin_sequence_editor_dialog
from . import xarkin_about_operator
from . import xarkin_account_management_operator
from . import xarkin_element_management_operator
from . import xarkin_cycle_design_dialog
from . import xarkin_single_design_dialog
from . import xarkin_gesture_design_dialog
from . import xarkin_sequence_design_dialog
from . import xarkin_add_armature_operator

preview_collections = {}
my_icons = previews.new()
icon_path = bpy.utils.user_resource('SCRIPTS') + "/addons/xarkin_operations/xarkin_operations.png"
my_icons.load("xarkin_operations", icon_path, 'IMAGE')
preview_collections["xarkin_operations"] = my_icons

class XarkinCustomMenu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_xarkin_custom_menu"
    bl_label = " Xarkin Animation Service"

    def draw(self, context):
        layout = self.layout
        if (xarkin_network_service.request_in_progress()):
            layout.operator("object.xarkin_null_abort_operator", text="Abort Request")
        elif (xarkin_network_service.result_available()):
            if (xarkin_network_service.global_first_import_frame == -1):
                import_arm_name = xarkin_network_service.get_import_armature_name()
                if (import_arm_name == None):
                    import_topology_name = xarkin_network_service.get_import_topology_name()
                    if (import_topology_name == None):
                        import_menu_item_str = 'Instantiate skeleton'
                    else:
                        import_menu_item_str = 'Instantiate ' + import_topology_name + ' skeleton'
                else:
                    import_menu_item_str = 'Import Received Frames'
            else:
                import_arm_name = xarkin_network_service.get_import_armature_name()
                number_of_import_frames = xarkin_network_service.get_number_of_import_frames()
                first_frame_string = str(xarkin_network_service.global_first_import_frame)
                if (import_arm_name == None):
                    arm_name_string = ' '
                else:
                    arm_name_string = ' for ' + str(import_arm_name) + ' '
                if (number_of_import_frames == None):
                    import_frame_count_string = ' '
                else:
                    import_frame_count_string = ' ' + str(number_of_import_frames) + ' '
                import_menu_item_str = 'Import' + import_frame_count_string + 'frames' + arm_name_string + 'starting at ' + first_frame_string
            layout.operator("object.xarkin_import_frames_operator", text=import_menu_item_str)
            layout.operator("object.xarkin_null_abort_operator", text="Abandon Result")
        elif (xarkin_network_service.importing_frames()):
            layout.operator("object.xarkin_null_abort_operator", text="Abort Import")
        else:
            layout.operator("object.xarkin_account_settings_dialog", text="Account Settings")
            if (xarkin_network_service.global_role == 'admin'):
                layout.operator("object.xarkin_account_management_operator", text="Manage Accounts")
            layout.operator("object.xarkin_element_management_operator", text="Manage Elements")
            layout.operator("object.xarkin_refresh_operator", text="Refresh")
            layout.separator()
            layout.operator("object.xarkin_create_mapping_operator", text="Create Mapping")
            layout.separator()
            layout.menu(AddMenu.bl_idname)
            layout.menu(CaptureMenu.bl_idname)
            layout.menu(ModifyMenu.bl_idname)
            layout.menu(EditMenu.bl_idname)
            layout.menu(DesignMenu.bl_idname)
            layout.separator()
            layout.operator("object.xarkin_about_operator", text="About")

def append_custom_menu(self, context):
    layout = self.layout
    if (not context.object) or (context.object.mode == 'OBJECT'):
        global preview_collections
        icon_val = preview_collections["xarkin_operations"]["xarkin_operations"].icon_id
        if xarkin_network_service.request_in_progress():
            layout.menu(XarkinCustomMenu.bl_idname, icon_value=icon_val, text=" Request Submitted")
        elif xarkin_network_service.result_available():
            layout.menu(XarkinCustomMenu.bl_idname, icon_value=icon_val, text=" Result Available")
        elif xarkin_network_service.importing_frames():
            layout.menu(XarkinCustomMenu.bl_idname, icon_value=icon_val, text=" Importing Frames")
        else:
            if not xarkin_network_service.idle():
                print("Unknown service state " + str(xarkin_network_service.global_request_state))
            layout.menu(XarkinCustomMenu.bl_idname, icon_value=icon_val, text=" Xarkin Animation Service")

class CaptureMenu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_xarkin_capture_menu"
    bl_label = " Capture"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.xarkin_single_capture_dialog", text="Capture Motion Element")
        layout.operator("object.xarkin_gesture_capture_dialog", text="Capture Gesture")

class AddMenu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_xarkin_add_menu"
    bl_label = " Add Armature"

    def draw(self, context):
        layout = self.layout
        op = layout.operator("object.xarkin_add_armature_operator", text="Humanoid")
        op.selected_option = 'humanoid'
        op = layout.operator("object.xarkin_add_armature_operator", text="Bird/Dinosaur")
        op.selected_option = "dino_bird"
        op = layout.operator("object.xarkin_add_armature_operator", text="Feline/Canine")
        op.selected_option = 'quad_toe'
        op = layout.operator("object.xarkin_add_armature_operator", text="Equine")
        op.selected_option = 'quad_tip_toe'
        op = layout.operator("object.xarkin_add_armature_operator", text="Reptile")
        op.selected_option = 'quad_heel_toe'
        op = layout.operator("object.xarkin_add_armature_operator", text="Triped")
        op.selected_option = 'triped'

class AppendMenu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_xarkin_append_menu"
    bl_label = " Append"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.xarkin_append_cycle_dialog", text="Append Cycle or Pose")
        layout.operator("object.xarkin_append_transition_dialog", text="Append Transition")

class ModifyMenu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_xarkin_modify_menu"
    bl_label = " Modify"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.xarkin_append_elements_dialog", text="Append Motion Elements")
        layout.operator("object.xarkin_walk_step_dialog", text="Modify Walk Step")
        layout.operator("object.xarkin_run_step_dialog", text="Modify Run Step")
        layout.operator("object.xarkin_turn_dialog", text="Superimpose Turn")

class EditMenu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_xarkin_edit_menu"
    bl_label = " Editors"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.xarkin_cycle_editor_dialog", text="Launch Cycle Editor")
        layout.operator("object.xarkin_single_editor_dialog", text="Launch Single Editor")
        layout.operator("object.xarkin_gesture_editor_dialog", text="Launch Gesture Editor")
        layout.operator("object.xarkin_sequence_editor_dialog", text="Launch Sequence Editor")

class DesignMenu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_xarkin_design_menu"
    bl_label = " Design"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.xarkin_cycle_design_dialog", text="Launch Cycle Designer")
        layout.operator("object.xarkin_single_design_dialog", text="Launch Single Designer")
        layout.operator("object.xarkin_gesture_design_dialog", text="Launch Gesture Designer")
        layout.operator("object.xarkin_sequence_design_dialog", text="Launch Script Designer")

# Register
classes = [
    XarkinCustomMenu,
    CaptureMenu,
    AddMenu,
    AppendMenu,
    ModifyMenu,
    EditMenu,
    DesignMenu,
    xarkin_add_armature_operator.XarkinAddArmatureOperator,
    xarkin_walk_step_dialog.XarkinWalkStepDialog,
    xarkin_run_step_dialog.XarkinRunStepDialog,
    xarkin_turn_dialog.XarkinTurnDialog,
    xarkin_single_capture_dialog.XarkinSingleCaptureDialog,
    xarkin_gesture_capture_dialog.XarkinGestureCaptureDialog,
    xarkin_append_cycle_dialog.XarkinAppendCycleDialog,
    xarkin_append_elements_dialog.XarkinAppendElementsDialog,
    xarkin_append_elements_dialog.AddElementButton,
    xarkin_append_elements_dialog.DeleteElementButton,
    xarkin_append_transition_dialog.XarkinAppendTransitionDialog,
    xarkin_message_dialog.XarkinMessageDialog,
    xarkin_message_dialog.XarkinNotImplementedDialog,
    xarkin_message_dialog.XarkinOperationNotAvailableOperator,
    xarkin_account_settings_dialog.XarkinAccountSettingsDialog,
    xarkin_import_frames_operator.XarkinImportFramesOperator,
    xarkin_refresh_operator.XarkinRefreshOperator,
    xarkin_create_mapping_operator.XarkinCreateMappingOperator,
    xarkin_cycle_editor_dialog.XarkinCycleEditorDialog,
    xarkin_single_editor_dialog.XarkinSingleEditorDialog,
    xarkin_gesture_editor_dialog.XarkinGestureEditorDialog,
    xarkin_sequence_editor_dialog.XarkinSequenceEditorDialog,
    xarkin_null_abort_operator.XarkinNullAbortOperator,
    xarkin_about_operator.XarkinAboutOperator,
    xarkin_account_management_operator.XarkinAccountManagementOperator,
    xarkin_element_management_operator.XarkinElementManagementOperator,
    xarkin_cycle_design_dialog.XarkinCycleDesignDialog,
    xarkin_single_design_dialog.XarkinSingleDesignDialog,
    xarkin_gesture_design_dialog.XarkinGestureDesignDialog,
    xarkin_sequence_design_dialog.XarkinSequenceDesignDialog
]

class ElementPropertyGroup(bpy.types.PropertyGroup):
    src: EnumProperty(items=xarkin_append_elements_dialog.get_element_source_items, name="", default=None)
    name: EnumProperty(items=xarkin_append_elements_dialog.get_all_name_items, name="", default=None)
    steps: EnumProperty(items=[
        ('auto', 'Auto', 'Server determines the optimum number of transition steps'),
        ('short', 'Short', 'Short transition'),
        ('medium', 'Medium', 'Medium transition'),
        ('long', 'Long', 'Long transition'),
        ('extra_long', 'Extra Long', 'Extra long transition'),
        ('none', 'None', 'Element is concatenated with no transition steps')], name="", default='auto')
    reps: IntProperty(name="", default=1, min=1, max=10)

def register():
    print('Xarkin Animation Services build number 2025.01.14.638724706905255223')
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    register_class(ElementPropertyGroup)
    bpy.types.Scene.element_properties = bpy.props.CollectionProperty(type=ElementPropertyGroup)

    bpy.types.VIEW3D_MT_editor_menus.append(append_custom_menu)
    thread = threading.Thread(target=xarkin_network_service.initiate_session)
    thread.start()

def unregister():
    bpy.types.VIEW3D_MT_editor_menus.remove(append_custom_menu)
    bpy.utils.previews.remove(my_icons)
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    
if __name__ == "__main__":
    register()
