# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

import bpy
import importlib
import time
import threading
from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty
        )
from . import xarkin_session_data
from . import xarkin_utilities
from . import xarkin_message_dialog
from . import xarkin_network_service
from . import xarkin_xml_exporter

global_parameters_xml = ''
global_interval_xml = ''
global_gravity_str = ''

def get_armature_items(self, context):
    item_list = []
    if hasattr(bpy.data, 'objects'):
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                next_item = [x.name, x.name, x.name]
                item_list.append(tuple(next_item))
    return item_list

def make_service_call():
    global global_parameters_xml
    global global_interval_xml
    global global_gravity_str
    xarkin_network_service.interval_service_request(xarkin_network_service.XAR_MODIFY_WALK_OPERATION, global_parameters_xml, global_interval_xml, global_gravity_str)

class XarkinWalkStepDialog(bpy.types.Operator):
    bl_idname = "object.xarkin_walk_step_dialog"
    bl_label = "Modify Walk Step"
    bl_description = "Requests a modification of the distance and elevation change for a walking step"

    network_service_busy = False

    wait_and_abort_options = [("wait", "Keep Waiting...", "Keep waiting for the current operation to complete."), ("abort", "Abort", "Abandon the current operation.")]
    wait_or_abort_prop: EnumProperty(name='Actions', items=wait_and_abort_options, default=wait_and_abort_options[0][0])

    armatures_prop: EnumProperty(items=get_armature_items, name="", default=None)
    mapping_source_prop: EnumProperty(items=xarkin_network_service.get_mapping_source_items, name="", default=None)
    mapping_name_prop: EnumProperty(items=xarkin_network_service.get_mapping_name_items, name="", default=None)
    gravity_prop: EnumProperty(items=xarkin_utilities.get_gravity_items, name="", default=None)
    custom_gravity_prop: FloatProperty(name="", default=0, min=-50, max=-0.1, precision=3)
    first_frame_prop: IntProperty(name="", default=1, min=1)
    last_frame_prop: IntProperty(name="", default=1, min=1, description="Armature keyframes after First Frame may be altered")
    step_distance_prop: FloatProperty(name="", default=0, precision=3)
    elevation_change_prop: FloatProperty(name="", default=0, precision=3)
    step_edge_prop: FloatProperty(name="", min=0.0, max=0.9, default=0.5, precision=3)
    step_speed_ratio_prop: FloatProperty(name="", min=0.5, max=2.0, default=1.0, precision=3)
    
    def draw(self, context):
        layout = self.layout
        
        if self.network_service_busy:
            layout.label(text="An operation is already in progress!")
            for option in self.wait_and_abort_options:
                layout.prop_enum(self, 'wait_or_abort_prop', option[0], text=option[1])
        else:
            row1 = layout.row()
            split1 = row1.split(factor=0.385)
            split1.label(text="Armature")
            split1.prop(self, 'armatures_prop')

            row2 = layout.row()
            split2 = row2.split(factor=0.70)
            src2_split = split2.split(factor=0.5714)
            src2_split.label(text='Mapping')
            src2_split.prop(self, 'mapping_source_prop')
            split2.prop(self, 'mapping_name_prop')

            if (self.gravity_prop == xarkin_utilities.XAR_CUSTOM_GRAVITY_VALUE):
                custom_gravity_row = layout.row()
                custom_gravity_row_split = custom_gravity_row.split(factor=0.70)
                custom_gravity_row_split_split = custom_gravity_row_split.split(factor=0.5714)
                custom_gravity_row_split_split.label(text='Gravity [m/s²]')
                custom_gravity_row_split_split.prop(self, 'gravity_prop')
                custom_gravity_row_split.prop(self, 'custom_gravity_prop')
            else:
                gravity_row = layout.row()
                gravity_row_split = gravity_row.split(factor=0.385)
                gravity_row_split.label(text="Gravity [m/s²]")
                gravity_row_split.prop(self, 'gravity_prop')
                self.custom_gravity_prop = float(self.gravity_prop)

            row3 = layout.row()
            split3 = row3.split(factor=0.385)
            split3.label(text="First Frame")
            split3.prop(self, 'first_frame_prop')
            
            row4 = layout.row()
            split4 = row4.split(factor=0.385)
            split4.label(text="Last Affected")
            split4.prop(self, 'last_frame_prop')
            split4.enabled = False
            
            row5 = layout.row()
            split5 = row5.split(factor=0.385)
            split5.label(text="Distance Change")
            split5.prop(self, 'step_distance_prop')
            
            row6 = layout.row()
            split6 = row6.split(factor=0.385)
            split6.label(text="Elevation Change")
            split6.prop(self, 'elevation_change_prop')
            
            row7 = layout.row()
            split7 = row7.split(factor=0.385)
            split7.label(text="Step Edge")
            split7.prop(self, 'step_edge_prop')
            
            row8 = layout.row()
            split8 = row8.split(factor=0.385)
            split8.label(text="Step Speed Ratio")
            split8.prop(self, 'step_speed_ratio_prop')

    def invoke(self, context, event):
        self.network_service_busy = not xarkin_network_service.idle()

        armature_count = 0
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                armature_count = armature_count + 1
        if (armature_count == 0):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No Armatures Available')
            return  {'FINISHED'}

        subject_arm_name = xarkin_session_data.get_subject_armature_name()
        self.armatures_prop = subject_arm_name
        if (subject_arm_name != None):
            armature_obj = bpy.data.objects[self.armatures_prop]
            anim_data = armature_obj.animation_data
            if (anim_data is not None) and (anim_data.action is not None):
                last_frame = 1
                for fcurve in anim_data.action.fcurves:
                    for key_frame in fcurve.keyframe_points:
                        if key_frame.co.x > last_frame:
                            last_frame = key_frame.co.x
                self.last_frame_prop = int(last_frame)

        self.first_frame_prop = min(int(self.last_frame_prop), bpy.context.scene.frame_current)

        most_recent_mapping_name = xarkin_session_data.get_session_variable("most_recent_mapping_name")
        if (not most_recent_mapping_name == None):
            m_items = xarkin_network_service.get_mapping_items(self, None)
            for item in m_items:
                if (item[1] == most_recent_mapping_name) or (('Standard:' + item[1]) == most_recent_mapping_name):
                    colon_pos = most_recent_mapping_name.find(':')
                    map_src = most_recent_mapping_name[0:colon_pos]
                    map_nam = most_recent_mapping_name[colon_pos + 1:]
                    self.mapping_source_prop = map_src
                    self.mapping_name_prop = map_nam

        most_recent_step_distance = xarkin_session_data.get_session_variable("most_recent_step_distance")
        if (not most_recent_step_distance == None):
                self.step_distance_prop = most_recent_step_distance
                
        most_recent_elevation_change = xarkin_session_data.get_session_variable("most_recent_elevation_change")
        if (not most_recent_elevation_change == None):
            self.elevation_change_prop = most_recent_elevation_change
                
        most_recent_step_edge = xarkin_session_data.get_session_variable("most_recent_step_edge")
        if (not most_recent_step_edge == None):
            self.step_edge_prop = most_recent_step_edge
                
        most_recent_step_speed_ratio = xarkin_session_data.get_session_variable("most_recent_step_speed_ratio")
        if (not most_recent_step_speed_ratio == None):
            self.step_speed_ratio_prop = most_recent_step_speed_ratio
                
        most_recent_gravity_choice = xarkin_session_data.get_session_variable("most_recent_gravity_choice")
        if (not most_recent_gravity_choice == None):
                self.gravity_prop = most_recent_gravity_choice
        most_recent_gravity_value = xarkin_session_data.get_session_variable("most_recent_gravity_value")
        if (not most_recent_gravity_value == None):
                self.custom_gravity_prop = most_recent_gravity_value
                
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        if self.network_service_busy:
            if (self.wait_or_abort_prop == 'abort'):
                xarkin_network_service.abort()
            return {'FINISHED'}
        xarkin_session_data.set_session_variable("most_recent_armature", self.armatures_prop)
        xarkin_session_data.set_session_variable("most_recent_mapping_name", self.mapping_source_prop + ':' + self.mapping_name_prop)
        xarkin_session_data.set_session_variable("most_recent_gravity_choice", self.gravity_prop)
        xarkin_session_data.set_session_variable("most_recent_gravity_value", self.custom_gravity_prop)
        xarkin_session_data.set_session_variable("most_recent_step_distance", self.step_distance_prop)
        xarkin_session_data.set_session_variable("most_recent_elevation_change", self.elevation_change_prop)
        xarkin_session_data.set_session_variable("most_recent_step_edge", self.step_edge_prop)
        xarkin_session_data.set_session_variable("most_recent_step_speed_ratio", self.step_speed_ratio_prop)
        if (self.mapping_source_prop == xarkin_utilities.XAR_NONE):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No mappings for this character.\nPlease create one before attempting operations.')
            return {'FINISHED'}
        first_frame = self.first_frame_prop
        last_frame = self.last_frame_prop
        if (last_frame == first_frame):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='First Frame and Last Frame should surround the\n'\
                'interval containing the step you would like to modify.\n'\
                    'The first candidate step in that interval will be modified.')
            return {'FINISHED'}
        elif (last_frame < first_frame):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Last Frame must be greater than First Frame.')
            return {'FINISHED'}
        elif ((last_frame - first_frame) < 10):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='This looks like too few frames to contain a step.\n'\
                'This warning is issued if the interval is less than 10 frames.')
            return {'FINISHED'}

        bpy.ops.ed.undo_push(message="Before requesting walk step modification.")

        exporter = xarkin_xml_exporter.EditorXMLExporter()

        first_export_frame = first_frame
        lead_buffer = 0
        for i in range(2):
            if (first_export_frame > 0):
                first_export_frame = first_export_frame - 1
                lead_buffer = lead_buffer + 1
        trail_buffer = 0
        interval_xml = exporter.get_mogen(self.armatures_prop, first_export_frame, last_frame)

        whole_mapping_name = self.mapping_name_prop
        if (self.mapping_source_prop != xarkin_utilities.XAR_STANDARD_NAME):
            whole_mapping_name = self.mapping_source_prop + ':' + self.mapping_name_prop

        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == whole_mapping_name):
                topology = mapping_list[mapping_index][0]

        parameters_xml = '<parameters>'
        parameters_xml += '<parameter name="operation" value="modify_walk_step" />'
        parameters_xml += '<parameter name="armature_name" value="' + self.armatures_prop + '" />'
        parameters_xml += '<parameter name="mapping_name" value="' + whole_mapping_name + '" />'
        parameters_xml += '<parameter name="topology" value="' + topology + '" />'
        parameters_xml += '<parameter name="first_frame" value="' + str(first_frame) + '" />'
        parameters_xml += '<parameter name="last_frame" value="' + str(last_frame) + '" />'
        parameters_xml += '<parameter name="lead_buffer" value="' + str(lead_buffer) + '" />'
        parameters_xml += '<parameter name="trail_buffer" value="' + str(trail_buffer) + '" />'
        parameters_xml += '<parameter name="step_distance" value="' "{:10.3f}".format(self.step_distance_prop)  + '" />'
        parameters_xml += '<parameter name="sequence_elevation_change" value="' "{:10.3f}".format(self.elevation_change_prop)  + '" />'
        parameters_xml += '<parameter name="step_edge" value="' "{:10.3f}".format(self.step_edge_prop)  + '" />'
        parameters_xml += '<parameter name="step_speed_ratio" value="' "{:10.3f}".format(self.step_speed_ratio_prop)  + '" />'
        parameters_xml += '</parameters>'

        global global_parameters_xml
        global global_interval_xml
        global global_gravity_str
        global_gravity_str = self.gravity_prop
        if (global_gravity_str == xarkin_utilities.XAR_CUSTOM_GRAVITY_VALUE):
            global_gravity_str = str(self.custom_gravity_prop)
        global_parameters_xml = parameters_xml
        global_interval_xml = interval_xml
        xarkin_network_service.global_first_import_frame = first_frame
        thread = threading.Thread(target=make_service_call)
        thread.start()
        return {'FINISHED'}
