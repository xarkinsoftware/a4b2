# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_MAX_APPEND_LEADIN_TIME = 1.0

import bpy
import importlib
import xml.dom.minidom
import time
import datetime
import threading
from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty,
        CollectionProperty
        )
from . import xarkin_session_data
from . import xarkin_utilities
from . import xarkin_message_dialog
from . import xarkin_network_service
from . import xarkin_xml_exporter

parameters_xml = ''
interval_xml = ''
elements_spec_xml = ''
gravity_string = ''

armature_name = ''
mapping_source = ''
mapping_name = ''

def get_armature_items(self, context):
    item_list = []
    if hasattr(bpy.data, 'objects'):
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                next_item = [x.name, x.name, x.name]
                item_list.append(tuple(next_item))
    return item_list

def get_element_source_items(self, context):
    cycles_list = xarkin_session_data.session_data[xarkin_session_data.XAR_CYCLES_DATA]
    item_list = xarkin_utilities.get_valid_source_items(armature_name, cycles_list, xarkin_network_service.global_userid)
    return item_list

def get_all_name_items(self, context):
    cycle_source_name = self.src
    cycle_list = get_source_qualified_cycle_name(self, cycle_source_name)
    combined_list = []
    if (cycle_list != None):
        for cycle in cycle_list:
            combined_list.append(cycle)
    single_list = get_source_qualified_single_name(self, cycle_source_name)
    if (single_list != None):
        for single in single_list:
            combined_list.append(single)
    return combined_list

def get_source_qualified_cycle_name(self, cycle_source_name):
    global armature_name
    global mapping_source
    global mapping_name
    whole_mapping_name = mapping_name
    if (mapping_source != xarkin_utilities.XAR_STANDARD_NAME):
        whole_mapping_name = mapping_source + ':' + mapping_name
    mappings_list = xarkin_session_data.session_data[xarkin_session_data.XAR_MAPPINGS_DATA]
    mapping_topology = "unknown"
    for mapping in mappings_list:
        if (mapping[1] == whole_mapping_name):
            mapping_topology = mapping[0]
    cycles_list = xarkin_session_data.session_data[xarkin_session_data.XAR_CYCLES_DATA]
    item_list = xarkin_utilities.get_valid_name_items(armature_name, cycles_list, cycle_source_name, mapping_topology)
    return item_list

def get_source_qualified_single_name(self, single_source_name):
    global armature_name
    global mapping_source
    global mapping_name
    whole_mapping_name = mapping_name
    if (mapping_source != xarkin_utilities.XAR_STANDARD_NAME):
        whole_mapping_name = mapping_source + ':' + mapping_name
    mappings_list = xarkin_session_data.session_data[xarkin_session_data.XAR_MAPPINGS_DATA]
    mapping_topology = "unknown"
    for mapping in mappings_list:
        if (mapping[1] == whole_mapping_name):
            mapping_topology = mapping[0]
    singles_list = xarkin_session_data.session_data[xarkin_session_data.XAR_SINGLES_DATA]
    item_list = xarkin_utilities.get_valid_name_items(armature_name, singles_list, single_source_name, mapping_topology)
    return item_list

def make_service_call():
    global parameters_xml
    global interval_xml
    global elements_spec_xml
    global gravity_string
    xarkin_network_service.append_service_request(parameters_xml, interval_xml, elements_spec_xml, gravity_string)

class AddElementButton(bpy.types.Operator):
    bl_idname = "object.add_element_button"
    bl_label = "+"

    row_number: IntProperty()

    def execute(self, context):
        context.scene.element_properties.add()
        for i in range(len(context.scene.element_properties) - 1, self.row_number, -1):
            context.scene.element_properties.move(i - 1, i)
        return {'FINISHED'}

class DeleteElementButton(bpy.types.Operator):
    bl_idname = "object.delete_element_button"
    bl_label = "-"

    row_number: IntProperty()

    def execute(self, context):
        context.scene.element_properties.remove(self.row_number)
        return {'FINISHED'}

class XarkinAppendElementsDialog(bpy.types.Operator):
    bl_idname = "object.xarkin_append_elements_dialog"
    bl_label = "Append Motion Elements"
    bl_description = "Append motion elements starting at a given frame"

    network_service_busy = False

    wait_and_abort_options = [("wait", "Keep Waiting...", "Keep waiting for the current operation to complete."), ("abort", "Abort", "Abandon the current operation.")]
    wait_or_abort_prop: EnumProperty(name='Actions', items=wait_and_abort_options, default=wait_and_abort_options[0][0])

    armatures_prop: EnumProperty(items=get_armature_items, name="", default=None)
    gravity_prop: EnumProperty(items=xarkin_utilities.get_gravity_items, name="", default=None)
    custom_gravity_prop: FloatProperty(name="", default=0, min=-50, max=-0.1, precision=3)
    mapping_source_prop: EnumProperty(items=xarkin_network_service.get_mapping_source_items, name="", default=None)
    mapping_name_prop: EnumProperty(items=xarkin_network_service.get_mapping_name_items, name="", default=None)
    first_frame_prop: IntProperty(name="", default=1, min=1)

    def draw(self, context):
        global armature_name
        global mapping_source
        global mapping_name
        layout = self.layout

        armature_name = self.armatures_prop
        mapping_source = self.mapping_source_prop
        mapping_name = self.mapping_name_prop
        
        if self.network_service_busy:
            layout.label(text="An operation is already in progress!")
            for option in self.wait_and_abort_options:
                layout.prop_enum(self, 'wait_or_abort_prop', option[0], text=option[1])
        else:
            armature_row = layout.row()
            armature_row_split = armature_row.split(factor=0.285)
            armature_row_split.label(text="Armature")
            armature_row_split.prop(self, 'armatures_prop')

            armature_name = self.armatures_prop

            mapping_row = layout.row()
            mapping_row_split_1 = mapping_row.split(factor=0.65)
            mapping_row_split_2 = mapping_row_split_1.split(factor=0.46154)
            mapping_row_split_2.label(text='Mapping')
            mapping_row_split_2.prop(self, 'mapping_source_prop')
            mapping_row_split_1.prop(self, 'mapping_name_prop')

            if (self.gravity_prop == xarkin_utilities.XAR_CUSTOM_GRAVITY_VALUE):
                custom_gravity_row = layout.row()
                custom_gravity_row_split = custom_gravity_row.split(factor=0.65)
                custom_gravity_row_split_split = custom_gravity_row_split.split(factor=0.46154)
                custom_gravity_row_split_split.label(text='Gravity [m/s²]')
                custom_gravity_row_split_split.prop(self, 'gravity_prop')
                custom_gravity_row_split.prop(self, 'custom_gravity_prop')
            else:
                gravity_row = layout.row()
                gravity_row_split = gravity_row.split(factor=0.285)
                gravity_row_split.label(text="Gravity [m/s²]")
                gravity_row_split.prop(self, 'gravity_prop')
                self.custom_gravity_prop = float(self.gravity_prop)
            
            first_frame_row = layout.row()
            first_frame_row_split = first_frame_row.split(factor=0.285)
            first_frame_row_split.label(text="First Frame")
            first_frame_row_split.prop(self, 'first_frame_prop')

            for i, item in enumerate(context.scene.element_properties):
                add_delete_row = layout.row()
                add_delete_row_split_1 = add_delete_row.split(factor=0.18)
                add_delete_row_split_2 = add_delete_row_split_1.split(factor=0.5)
                add_button = add_delete_row_split_2.operator("object.add_element_button")
                add_button.row_number = i
                del_button = add_delete_row_split_2.operator("object.delete_element_button")
                del_button.row_number = i
                
                element_row = layout.row()
                element_row_split_1 = element_row.split(factor=0.65)
                element_row_split_2 = element_row_split_1.split(factor=0.46154)
                element_row_split_2.label(text='Element')
                element_row_split_2.prop(item, 'src')
                element_row_split_1.prop(item, 'name')

                transition_row = layout.row()
                transition_row_split = transition_row.split(factor=0.285)
                transition_row_split.label(text="Transit Steps")
                transition_row_split.prop(item, 'steps')

                cycle_items = get_source_qualified_cycle_name(self, item.src)
                selected_index = -1
                for item_index, cycle_item in enumerate(cycle_items):
                    if cycle_item[0] == item.name:
                        selected_index = item_index
                if (selected_index != -1):
                    repetition_row = layout.row()
                    repetition_row_split = repetition_row.split(factor=0.285)
                    repetition_row_split.label(text="Repetitions")
                    repetition_row_split.prop(item, 'reps')
            
            add_element_row = layout.row()
            add_element_row_split_1 = add_element_row.split(factor=0.08)
            add_element_button = add_element_row_split_1.operator("object.add_element_button")
            add_element_button.row_number = len(context.scene.element_properties)

    def invoke(self, context, event):
        self.network_service_busy = not xarkin_network_service.idle()

        armature_count = 0
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                armature_count = armature_count + 1
        if (armature_count == 0):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No Armatures Available')
            return  {'FINISHED'}

        subject_arm_name = xarkin_session_data.get_subject_armature_name()
        self.armatures_prop = subject_arm_name
        if (subject_arm_name != None):
            armature_obj = bpy.data.objects[self.armatures_prop]
            anim_data = armature_obj.animation_data
            if (anim_data is not None) and (anim_data.action is not None):
                last_frame = 1
                for fcurve in anim_data.action.fcurves:
                    for key_frame in fcurve.keyframe_points:
                        if key_frame.co.x > last_frame:
                            last_frame = key_frame.co.x
                self.first_frame_prop = int(last_frame) + 1

        most_recent_mapping_name = xarkin_session_data.get_session_variable("most_recent_mapping_name")
        set_mapping_name = False
        if (not most_recent_mapping_name == None):
            m_items = xarkin_network_service.get_mapping_items(self, None)
            for item in m_items:
                if (item[1] == most_recent_mapping_name) or (('Standard:' + item[1]) == most_recent_mapping_name):
                    colon_pos = most_recent_mapping_name.find(':')
                    map_src = most_recent_mapping_name[0:colon_pos]
                    map_nam = most_recent_mapping_name[colon_pos + 1:]
                    self.mapping_source_prop = map_src
                    self.mapping_name_prop = map_nam
                    set_mapping_name = True
        if not set_mapping_name:
            mapping_sources = xarkin_network_service.get_mapping_source_items(self, context)
            if (len(mapping_sources) > 0):
                self.mapping_source_prop = mapping_sources[0][0]
            mapping_names = xarkin_network_service.get_mapping_name_items(self, context)
            if (len(mapping_names) > 0):
                self.mapping_name_prop = mapping_names[0][0]

        most_recent_gravity_choice = xarkin_session_data.get_session_variable("most_recent_gravity_choice")
        if (not most_recent_gravity_choice == None):
                self.gravity_prop = most_recent_gravity_choice
        most_recent_gravity_value = xarkin_session_data.get_session_variable("most_recent_gravity_value")
        if (not most_recent_gravity_value == None):
                self.custom_gravity_prop = most_recent_gravity_value
                
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        if self.network_service_busy:
            if (self.wait_or_abort_prop == 'abort'):
                xarkin_network_service.abort()
            return {'FINISHED'}
        xarkin_session_data.set_session_variable("most_recent_armature", self.armatures_prop)
        xarkin_session_data.set_session_variable("most_recent_mapping_name", self.mapping_source_prop + ':' + self.mapping_name_prop)
        xarkin_session_data.set_session_variable("most_recent_gravity_choice", self.gravity_prop)
        xarkin_session_data.set_session_variable("most_recent_gravity_value", self.custom_gravity_prop)
        if (self.mapping_source_prop == xarkin_utilities.XAR_NONE):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No mappings for this character.\nPlease create one before attempting operations.')
            return {'FINISHED'}
        first_frame = self.first_frame_prop

        global gravity_string
        gravity_string = self.gravity_prop
        if (gravity_string == xarkin_utilities.XAR_CUSTOM_GRAVITY_VALUE):
            gravity_string = str(self.custom_gravity_prop)

        bpy.ops.ed.undo_push(message="Before requesting cycle or pose append.")
        
        exporter = xarkin_xml_exporter.EditorXMLExporter()

        first_export_frame = first_frame - 1
        lead_buffer = 0
        # max_lead_in_frames = 2
        max_lead_in_frames = round(bpy.context.scene.render.fps * XAR_MAX_APPEND_LEADIN_TIME)    # contact inference error if leadin is stationary (no keyframes)
        for i in range(max_lead_in_frames):
            if (first_export_frame > 0):
                first_export_frame = first_export_frame - 1
                lead_buffer = lead_buffer + 1
        last_export_frame = first_frame - 1
        global interval_xml

        arm_name = self.armatures_prop
        arm_node = None
        for obj in bpy.context.scene.objects:
            if ((obj.type == "ARMATURE") and (obj.name == arm_name)):
                arm_node = obj

        if ((arm_node is None) or (arm_node.animation_data is None) or (arm_node.animation_data.action is None)):
            print('Requesting empty sequence')
            interval_xml = exporter.get_mogen(self.armatures_prop, -1, -1)
        else:
            interval_xml = exporter.get_mogen(self.armatures_prop, first_export_frame, last_export_frame)

        whole_mapping_name = self.mapping_name_prop
        if (self.mapping_source_prop != xarkin_utilities.XAR_STANDARD_NAME):
            whole_mapping_name = self.mapping_source_prop + ':' + self.mapping_name_prop

        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == whole_mapping_name):
                topology = mapping_list[mapping_index][0]

        global parameters_xml
        parameters_xml = '<parameters>'
        parameters_xml += '<parameter name="operation" value="append_elements" />'
        parameters_xml += '<parameter name="armature_name" value="' + self.armatures_prop + '" />'
        parameters_xml += '<parameter name="mapping_name" value="' + whole_mapping_name + '" />'
        parameters_xml += '<parameter name="topology" value="' + topology + '" />'
        parameters_xml += '<parameter name="first_frame" value="' + str(first_frame) + '" />'
        parameters_xml += '<parameter name="lead_buffer" value="' + str(lead_buffer) + '" />'
        parameters_xml += '</parameters>'

        global elements_spec_xml
        elements_spec_xml = '<append_elements>'
        for i, item in enumerate(context.scene.element_properties):
            elements_spec_xml += '<element name="' + item.src + ':' + item.name + '" index="' + str(i) + '" transition_steps="' + str(item.steps) + '" repetitions="' + str(item.reps) + '"/>'
        elements_spec_xml += '</append_elements>'

        xarkin_network_service.global_first_import_frame = first_frame
        thread = threading.Thread(target=make_service_call)
        thread.start()
        return {'FINISHED'}
