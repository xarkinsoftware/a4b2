# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

import datetime
import io
import os
import time
import math
import shutil
import subprocess
import bpy
import mathutils
from mathutils import Vector
import xml
import xml.dom
import xml.dom.minidom
import socket
import operator
import tempfile

from . import xarkin_utilities

XAR_EDITOR_TAG = "editor"
XAR_ASSEMBLY_TAG = "assembly"
XAR_FRAME_TAG = "frame"
XAR_FRAMES_TAG = "frames"
XAR_DISPLACEMENT_ATTR = "displacement"
XAR_FRAMERATE_ATTR = "frame_rate"

XAR_DIRECTORY_ATTR = "directory"
XAR_HEADING_ATTR = "heading"

XAR_SEGMENT_TAG = "segment"
XAR_JOINT_TAG = "joint"

XAR_ID_ATTR = "id"
XAR_INDEX_ATTR = "index"
XAR_NAME_ATTR = "name"
XAR_LENGTH_ATTR = "length"
XAR_BASE_ID_ATTR = "base_id"
XAR_BASE_INDEX_ATTR = "base_index"
XAR_ADDED_ID_ATTR = "added_id"
XAR_ADDED_INDEX_ATTR = "added_index"
XAR_HEAD_ATTR = "head"
XAR_TAIL_ATTR = "tail"
XAR_BONE_ROTATION = "rotation"
XAR_FILL_IN_MARKER = "_fill_in_invisible"

XAR_MOGEN_TAG = "mogen"
XAR_DELTA_HEADING_ATTR = "delta_heading"

EDITOR_FILE_IDENTIFIER = "XarkinEditor_"
EDITOR_FILE_SUFFIX = ".xmogen"
EDITOR_EXECUTABLE = "editor.exe"
EDITOR_NPM_COMMAND = "npm run start_minimal"

OUTPUT_FORMAT = '{0:.6f}'

def set_select(object, isSelected):
    object.select_set(isSelected)
        
def set_active(object):
    bpy.context.view_layer.objects.active = object

def set_hide(object, isHidden):
    object.hide_set(isHidden)
        
def xarkin_editor_alert(message):
    bpy.ops.error.xel_message('INVOKE_DEFAULT', msg=message)
    
class EditorXMLExporter:
    
    xScale = 1
    yScale = 1
    zScale = 1
    xRotation = False
    
    def indent(self, depth):
        space = ""
        for i in range(0, depth):
            space += "   "
        return space

    def get_pose_bone_head(self, bone):
        if (self.xRotation):
            return Vector([bone.head.x * self.xScale, -bone.head.z * self.zScale, bone.head.y * self.yScale])
        else:
            return Vector([bone.head.x * self.xScale, bone.head.y * self.yScale, bone.head.z * self.zScale])

    def get_pose_bone_tail(self, bone):
        if (self.xRotation):
            return Vector([bone.tail.x * self.xScale, -bone.tail.z * self.zScale, bone.tail.y * self.yScale])
        else:
            return Vector([bone.tail.x * self.xScale, bone.tail.y * self.yScale, bone.tail.z * self.zScale])

    def export_pose_armature_bone(self, bone, depth, previous_tail):
        pose_bone_head = self.get_pose_bone_head(bone)
        pose_bone_tail = self.get_pose_bone_tail(bone)
        previous_tail_to_head = previous_tail - pose_bone_head
        added_fill_in = False
        buff = ''
        if (previous_tail_to_head.length > 1e-3):
            added_fill_in = True
            buff += self.indent(depth) + '<segment name="' + bone.name + XAR_FILL_IN_MARKER
            buff += '" head="' + OUTPUT_FORMAT.format(previous_tail.x) + ', ' + OUTPUT_FORMAT.format(previous_tail.y) + ', ' + OUTPUT_FORMAT.format(previous_tail.z)
            buff += '" tail="' + OUTPUT_FORMAT.format(pose_bone_head.x) + ', ' + OUTPUT_FORMAT.format(pose_bone_head.y) + ', ' + OUTPUT_FORMAT.format(pose_bone_head.z) + '" '
            buff += ' >\n'
        
        buff += self.indent(depth) + '<segment name="' + bone.name
        buff += '" head="' + OUTPUT_FORMAT.format(pose_bone_head.x) + ', ' + OUTPUT_FORMAT.format(pose_bone_head.y) + ', ' + OUTPUT_FORMAT.format(pose_bone_head.z)
        buff += '" tail="' + OUTPUT_FORMAT.format(pose_bone_tail.x) + ', ' + OUTPUT_FORMAT.format(pose_bone_tail.y) + ', ' + OUTPUT_FORMAT.format(pose_bone_tail.z) + '" '
        buff += ' rotation="0"'
        if (bone.children.__len__() > 0):
            buff += ' >\n'
            for child in bone.children:
                buff += self.export_pose_armature_bone(child, depth+1, pose_bone_tail)
            buff += self.indent(depth) + '</segment>\n'
        else:
            buff += ' />\n'
            
        if (added_fill_in):
            buff += self.indent(depth) + '</segment>\n'

        return buff

    def export_sequence_frames(self, arm_node, root_name, first_frame_index, last_frame_index, depth):
        print('export_sequence_frames')
        prev_node = bpy.context.active_object
        hold_frame = bpy.context.scene.frame_current
        set_active(arm_node)

        root_bone = None
        for b in arm_node.pose.bones:
            if ((b.parent != None) or (b.name != root_name)):
                continue
            root_bone = b
        buff = ""
        for f in range(first_frame_index, last_frame_index + 1):
            bpy.context.scene.frame_set(f)
            [frame_x, frame_y, frame_z, frame_heading] = xarkin_utilities.get_location_and_heading(arm_node)
            root_bone_head = self.get_pose_bone_head(root_bone)
            this_frame_buff = self.indent(depth) + '<frame index="' + str(f) + '" heading="' + OUTPUT_FORMAT.format(frame_heading) + '" >\n'
            this_frame_buff += self.export_pose_armature_bone(root_bone, depth+1, root_bone_head)
            this_frame_buff += self.indent(depth) + '</frame>\n'
            counter_rotated_frame = xarkin_utilities.counter_rotate_frame(this_frame_buff, root_name, frame_heading)
            buff += counter_rotated_frame
        bpy.context.scene.frame_set(hold_frame)
        set_active(prev_node)
        return buff

    def get_data_bone_head(self, bone):
        if (self.xRotation):
            return Vector([bone.head_local.x * self.xScale, -bone.head_local.z * self.zScale, bone.head_local.y * self.yScale])
        else:
            return Vector([bone.head_local.x * self.xScale, bone.head_local.y * self.yScale, bone.head_local.z * self.zScale])

    def get_data_bone_tail(self, bone):
        if (self.xRotation):
            return Vector([bone.tail_local.x * self.xScale, -bone.tail_local.z * self.zScale, bone.tail_local.y * self.yScale])
        else:
            return Vector([bone.tail_local.x * self.xScale, bone.tail_local.y * self.yScale, bone.tail_local.z * self.zScale])

    def export_rest_armature_bone(self, bone, depth, min_max, previous_tail):
        data_bone_head = self.get_data_bone_head(bone)
        data_bone_tail = self.get_data_bone_tail(bone)

        previous_tail_to_head = previous_tail - data_bone_head
        added_fill_in = False
        buff = ''
        if (previous_tail_to_head.length > 1e-3):
            added_fill_in = True
            buff += self.indent(depth) + '<segment name="' + bone.name + XAR_FILL_IN_MARKER
            buff += '" head="' + OUTPUT_FORMAT.format(previous_tail.x) + ', ' + OUTPUT_FORMAT.format(previous_tail.y) + ', ' + OUTPUT_FORMAT.format(previous_tail.z)
            buff += '" tail="' + OUTPUT_FORMAT.format(data_bone_head.x) + ', ' + OUTPUT_FORMAT.format(data_bone_head.y) + ', ' + OUTPUT_FORMAT.format(data_bone_head.z) + '" '
            buff += ' >\n'
        
        min_max[0] = min(min_max[0], data_bone_head.z)
        min_max[1] = max(min_max[1], data_bone_head.z)
        buff += self.indent(depth) + '<segment name="' + bone.name
        buff += '" head="' + OUTPUT_FORMAT.format(data_bone_head.x) + ', ' + OUTPUT_FORMAT.format(data_bone_head.y) + ', ' + OUTPUT_FORMAT.format(data_bone_head.z)
        buff += '" tail="' + OUTPUT_FORMAT.format(data_bone_tail.x) + ', ' + OUTPUT_FORMAT.format(data_bone_tail.y) + ', ' + OUTPUT_FORMAT.format(data_bone_tail.z) + '" '
        if (bone.children.__len__() > 0):
            buff += ' >\n'
            for child in bone.children:
                buff += self.export_rest_armature_bone(child, depth+1, min_max, data_bone_tail)
            buff += self.indent(depth) + '</segment>\n'
        else:
            buff += ' />\n'

        if (added_fill_in):
            buff += self.indent(depth) + '</segment>\n'

        return buff

    def export_rest_armature(self, arm_node, root_name, depth, min_max):
        if ((arm_node.rotation_euler.order[0] == 'X') and (math.fabs(math.fabs(arm_node.rotation_euler.x) - math.pi/2) < 0.01)):
            self.xRotation = True
        set_active(arm_node)

        buff = self.indent(depth) + '<rest>\n'
        for bone in arm_node.data.bones:
            if ((bone.parent != None) or (bone.name != root_name)):
                continue
            root_bone_head = self.get_data_bone_head(bone)
            buff += self.export_rest_armature_bone(bone, depth+1, min_max, root_bone_head)
        buff += self.indent(depth) + '</rest>\n'

        set_active(arm_node)
        return buff

    def export_sequence(self, arm_node, root_name, first_frame_index, last_frame_index, min_max):
        try:
            set_active(arm_node)
            set_hide(arm_node, False)
            set_select(arm_node, True)
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception as exc:
            print("Failed to export sequence\n" + str(exc))
            return "Failed to export sequence."

        if ((arm_node.rotation_euler.order[0] == 'X') and (math.fabs(math.fabs(arm_node.rotation_euler.x) - math.pi/2) < 0.01)):
            self.xRotation = True

        buff = '      <sequence frame_rate="' + str(bpy.context.scene.render.fps) + '">\n'
        buff += self.export_rest_armature(arm_node, root_name, 3, min_max)
        if ((first_frame_index >= 0) and (last_frame_index >= 0)):
            buff += self.export_sequence_frames(arm_node, root_name, first_frame_index, last_frame_index, 3)
        buff += '      </sequence>\n'
        
        return buff
        
    def __init__(self):
        self.scene = bpy.context.scene

    def export_assembly_bone(self, segment_str_list, joint_str_list, bone, previous_name, previous_tail):
        data_bone_head = self.get_data_bone_head(bone)
        data_bone_tail = self.get_data_bone_tail(bone)

        previous_tail_to_head = previous_tail - data_bone_head
        if (previous_tail_to_head.length > 1e-3):
            fill_in_bone_name = bone.name + XAR_FILL_IN_MARKER

            joint_name = previous_name + "_to_" + fill_in_bone_name
            joint_buff = '<joint name="' + joint_name + '"'
            joint_buff += ' base="' + previous_name + '" added="' + fill_in_bone_name + '" />'
            joint_str_list.append(joint_buff)

            segment_buff = '<segment name="' + fill_in_bone_name + '"'
            segment_buff += ' length="' + OUTPUT_FORMAT.format(previous_tail_to_head.length) + '"'
            segment_buff += ' />'
            segment_str_list.append(segment_buff)

            previous_name = fill_in_bone_name

        bone_vector = data_bone_tail - data_bone_head
        bone_length = bone_vector.length

        if (len(previous_name) > 0):
            joint_name = previous_name + "_to_" + bone.name
            joint_buff = '<joint name="' + joint_name + '"'
            joint_buff += ' base="' + previous_name + '" added="' + bone.name + '" />'
            joint_str_list.append(joint_buff)

        segment_buff = '<segment name="' + bone.name + '"'
        segment_buff += ' length="' + OUTPUT_FORMAT.format(bone_length) + '"'
        segment_buff += ' />'
        segment_str_list.append(segment_buff)
        if (bone.children.__len__() > 0):
            for child in bone.children:
                self.export_assembly_bone(segment_str_list, joint_str_list, child, bone.name, data_bone_tail)

    def export_assembly(self, arm_node, root_name, depth):
        set_active(arm_node)

        segment_str_list = []
        joint_str_list = []
        anchor_name = ""
        anchor_data_bone = None
        for bone in arm_node.data.bones:
            if ((bone.parent == None) and (bone.name == root_name)):
                anchor_data_bone = bone
                anchor_name = bone.name
        if (len(anchor_name) == 0):
            return "Failed to export armature."
        buff = self.indent(depth) + '<assembly anchor_name="' + anchor_name + '" >\n'
        root_bone_head = self.get_data_bone_head(anchor_data_bone)
        self.export_assembly_bone(segment_str_list, joint_str_list, anchor_data_bone, "", root_bone_head)
        for seg in segment_str_list:
            buff += self.indent(depth + 1) + seg + '\n'
        for joint in joint_str_list:
            buff += self.indent(depth + 1) + joint + '\n'
        buff += self.indent(depth) + '</assembly>\n'

        set_active(arm_node)
        return buff

    def get_mogen(self, arm_name, first_frame, last_frame):
        arm_node = None
        for obj in self.scene.objects:
            if ((obj.type == "ARMATURE") and (obj.name == arm_name)):
                arm_node = obj
        if (arm_node == None):
            print("Return because armature not found.")
            return "Armature '" + arm_name + "' not found."

        self.xScale = arm_node.scale.x
        self.yScale = arm_node.scale.y
        self.zScale = arm_node.scale.z
        root_name = ""
        for bone in arm_node.data.bones:
            if (bone.parent == None):
                root_name = bone.name
        if (len(root_name) == 0):
            print("Return because of invalid armature.")
            return ("Invalid armature " + arm_name + ".")

        min_max = [10000, -10000]
        assembly_xml = self.export_assembly(arm_node, root_name, 2)
        if (not (assembly_xml.strip()[0] == '<')):
            print("Return because of assembly export failure.")
            return assembly_xml
        sequence_xml = self.export_sequence(arm_node, root_name, first_frame, last_frame, min_max)
        if (not (sequence_xml.strip()[0] == '<')):
            print("Return because of sequence export failure.")
            return sequence_xml

        export_buffer = '<?xml version="1.0" encoding="utf-8"?>\n'
        export_buffer += '   <' + XAR_MOGEN_TAG
        export_buffer += ' ' + XAR_DELTA_HEADING_ATTR + '="0" >\n'
#        export_buffer += ' ' + XAR_DELTA_HEADING_ATTR + '="' + str(delta_heading) + '" >\n'
        export_buffer += assembly_xml
        export_buffer += sequence_xml
        export_buffer += '   </' + XAR_MOGEN_TAG + '>\n'

        return export_buffer
