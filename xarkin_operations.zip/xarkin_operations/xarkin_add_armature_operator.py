# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

import bpy
import threading
import importlib

from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty,
        CollectionProperty
        )

from . import xarkin_network_service
from . import xarkin_utilities

def make_service_call():
    global parameters_xml
    xarkin_network_service.append_service_request(parameters_xml, '', '', xarkin_utilities.XAR_EARTH_GRAVITY_VALUE)

class XarkinAddArmatureOperator(bpy.types.Operator):
    bl_idname = "object.xarkin_add_armature_operator"
    bl_label = "Add Armature"
    bl_description = "Requests a skeleton from the cloud"

    selected_option: StringProperty(default="humanoid")

    def execute(self, context):

        topology = str(self.selected_option)
        if (topology == 'humanoid'):
            if not xarkin_network_service.idle():
                if (self.wait_or_abort_prop == 'abort'):
                    xarkin_network_service.abort()
                return {'FINISHED'}
            global parameters_xml
            parameters_xml = '<parameters>'
            parameters_xml += '<parameter name="operation" value="instantiate_armature" />'
            parameters_xml += '<parameter name="topology" value="' + topology + '" />'
            parameters_xml += '</parameters>'

            xarkin_network_service.global_first_import_frame = -1
            thread = threading.Thread(target=make_service_call)
            thread.start()
        else:
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Selected armature not available for this account.')
        return {'FINISHED'}

